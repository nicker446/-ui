# 🍜 校园外卖App UI设计

一款采用高端极简主义设计风格的校园外卖App界面，使用毛玻璃效果、渐变背景和流畅动画打造iOS级别的用户体验。

## ✨ 设计特点

- 🎨 **毛玻璃材质设计系统** - backdrop-blur效果打造透明层次感
- ✨ **iOS级别的流畅动画** - 基于Motion库的细腻交互体验
- 🎯 **低饱和度高级配色** - 鹅卵石般立体圆润的质感
- 📱 **15个完整功能页面** - 覆盖完整的用户使用流程
- 🧩 **可复用的组件库** - 统一的玻璃质感UI组件系统

## 🛠 技术栈

- **框架**: React 18 + TypeScript
- **路由**: React Router 7
- **样式**: Tailwind CSS 4
- **动画**: Motion (Framer Motion)
- **UI组件**: 自定义玻璃质感组件 + Shadcn/ui
- **图标**: Lucide React

## 📦 功能模块

### 核心页面
- **首页** - 推荐餐厅、热门分类、搜索功能
- **分类** - 12个食品分类网格展示
- **订单** - 订单列表与详情查看
- **个人中心** - 用户信息与设置入口

### 功能页面
- 餐厅详情 / 分类详情 / 购物车
- 搜索 / 收藏 / 优惠券
- 地址管理 / 订单详情 / 全部餐厅
- 帮助中心 / 设置

## 🎨 设计系统

### 玻璃质感组件
- `GlassCard` - 基础玻璃卡片
- `GlassButton` - 玻璃按钮
- `GlassIconButton` - 图标按钮
- `AnimatedGlassCard` - 带动画的玻璃卡片
- `AnimatedGlassButton` - 带动画的玻璃按钮

### 动画系统
- 页面过渡动画 (PageTransition)
- 列表错落动画 (StaggerContainer)
- iOS风格的Spring动画
- Hover与点击反馈

### 配色方案
- 低饱和度渐变背景
- 半透明毛玻璃卡片
- 精致的阴影与高光
- 柔和的强调色

## 📂 项目结构

```
src/app/
├── components/          # UI组件库
│   ├── GlassCard.tsx
│   ├── GlassButton.tsx
│   ├── AnimatedGlass*.tsx
│   ├── BottomNav.tsx
│   └── ui/             # Shadcn组件
├── pages/              # 15个功能页面
├── data/               # 数据层
│   ├── categories.ts   # 12个分类
│   └── restaurants.ts  # 16家餐厅
├── utils/              # 工具函数
│   └── animations.ts   # 动画配置
└── routes.tsx          # 路由配置
```

## 🚀 快速开始

### 安装依赖
```bash
npm install
# 或
pnpm install
```

### 本地开发
```bash
npm run dev
```

### 构建生产版本
```bash
npm run build
```

## 💡 设计理念

本项目追求**高端极简主义**的设计风格：
- 充足的留白提升视觉呼吸感
- 圆润的圆角营造亲和力
- 毛玻璃效果增加层次感
- 精致的阴影打造立体感
- 低饱和度配色彰显高级感

每个交互都经过精心设计，力求达到iOS原生应用的流畅度和细腻度。

## 📊 数据说明

项目包含完整的模拟数据：
- **12个食品分类** - 涵盖主流餐饮类型
- **16家配套餐厅** - 与分类一一对应
- **统一数据管理** - 确保数据一致性

---

**作者**: [你的名字]  
**日期**: 2026年3月  
**技术**: React + TypeScript + Tailwind CSS
