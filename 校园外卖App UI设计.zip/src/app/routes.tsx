import { createBrowserRouter } from "react-router";
import Home from "./pages/Home";
import Categories from "./pages/Categories";
import Orders from "./pages/Orders";
import Profile from "./pages/Profile";
import RestaurantDetail from "./pages/RestaurantDetail";
import Cart from "./pages/Cart";
import Address from "./pages/Address";
import Favorites from "./pages/Favorites";
import Coupons from "./pages/Coupons";
import Settings from "./pages/Settings";
import Help from "./pages/Help";
import Search from "./pages/Search";
import CategoryDetail from "./pages/CategoryDetail";
import OrderDetail from "./pages/OrderDetail";
import AllRestaurants from "./pages/AllRestaurants";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/categories",
    element: <Categories />,
  },
  {
    path: "/orders",
    element: <Orders />,
  },
  {
    path: "/profile",
    element: <Profile />,
  },
  {
    path: "/restaurant",
    element: <RestaurantDetail />,
  },
  {
    path: "/cart",
    element: <Cart />,
  },
  {
    path: "/address",
    element: <Address />,
  },
  {
    path: "/favorites",
    element: <Favorites />,
  },
  {
    path: "/coupons",
    element: <Coupons />,
  },
  {
    path: "/settings",
    element: <Settings />,
  },
  {
    path: "/help",
    element: <Help />,
  },
  {
    path: "/search",
    element: <Search />,
  },
  {
    path: "/category",
    element: <CategoryDetail />,
  },
  {
    path: "/order",
    element: <OrderDetail />,
  },
  {
    path: "/all-restaurants",
    element: <AllRestaurants />,
  },
]);