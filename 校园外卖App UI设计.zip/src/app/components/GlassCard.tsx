import { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}

export default function GlassCard({ children, className = "", onClick }: GlassCardProps) {
  return (
    <div
      onClick={onClick}
      className={`
        relative
        bg-gradient-to-br from-white/70 via-white/60 to-white/50
        backdrop-blur-2xl
        border-2 border-white/60
        rounded-[2rem]
        transition-all duration-300
        ${className}
      `}
      style={{
        boxShadow: `
          0 8px 32px rgba(0, 0, 0, 0.08),
          0 16px 64px rgba(0, 0, 0, 0.06),
          inset 0 2px 4px rgba(255, 255, 255, 0.95),
          inset 0 -2px 4px rgba(0, 0, 0, 0.05)
        `,
      }}
    >
      {/* 顶部高光 - 鹅卵石效果 */}
      <div 
        className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/40 to-transparent rounded-[2rem] pointer-events-none"
        style={{ maskImage: 'linear-gradient(to bottom, black 0%, transparent 100%)' }}
      />
      
      {/* 边缘高光 */}
      <div 
        className="absolute inset-0 rounded-[2rem] pointer-events-none"
        style={{
          background: 'linear-gradient(135deg, rgba(255,255,255,0.5) 0%, transparent 50%, rgba(0,0,0,0.03) 100%)',
          opacity: 0.6,
        }}
      />
      
      {children}
    </div>
  );
}
