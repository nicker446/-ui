import { ReactNode } from "react";
import { motion } from "motion/react";

interface AnimatedGlassCardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  delay?: number;
  interactive?: boolean;
}

// iOS风格的弹簧动画配置
const springConfig = {
  type: "spring",
  stiffness: 400,
  damping: 28,
  mass: 0.6,
} as const;

export default function AnimatedGlassCard({ 
  children, 
  className = "", 
  onClick,
  delay = 0,
  interactive = true,
}: AnimatedGlassCardProps) {
  return (
    <motion.div
      onClick={onClick}
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        ...springConfig,
        delay,
      }}
      whileHover={interactive ? {
        scale: 1.02,
        y: -4,
        transition: { ...springConfig, delay: 0 },
      } : {}}
      whileTap={interactive && onClick ? {
        scale: 0.98,
        y: 0,
        transition: { ...springConfig, delay: 0 },
      } : {}}
      className={`
        relative
        bg-gradient-to-br from-white/70 via-white/60 to-white/50
        backdrop-blur-2xl
        border-2 border-white/60
        rounded-[2rem]
        ${onClick ? 'cursor-pointer' : ''}
        ${className}
      `}
      style={{
        boxShadow: `
          0 8px 32px rgba(0, 0, 0, 0.08),
          0 16px 64px rgba(0, 0, 0, 0.06),
          inset 0 2px 4px rgba(255, 255, 255, 0.95),
          inset 0 -2px 4px rgba(0, 0, 0, 0.05)
        `,
      }}
    >
      {/* 顶部高光 - 鹅卵石效果 */}
      <div 
        className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/40 to-transparent rounded-[2rem] pointer-events-none"
        style={{ maskImage: 'linear-gradient(to bottom, black 0%, transparent 100%)' }}
      />
      
      {/* 边缘高光 */}
      <div 
        className="absolute inset-0 rounded-[2rem] pointer-events-none"
        style={{
          background: 'linear-gradient(135deg, rgba(255,255,255,0.5) 0%, transparent 50%, rgba(0,0,0,0.03) 100%)',
          opacity: 0.6,
        }}
      />
      
      {children}
    </motion.div>
  );
}
