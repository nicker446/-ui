import { ReactNode } from "react";
import { motion } from "motion/react";

interface AnimatedGlassButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "danger" | "success" | "icon";
  size?: "sm" | "md" | "lg";
  className?: string;
  disabled?: boolean;
}

// iOS风格的弹簧动画配置
const springConfig = {
  type: "spring",
  stiffness: 500,
  damping: 25,
  mass: 0.5,
} as const;

// 轻盈的弹簧配置（用于hover）
const lightSpringConfig = {
  type: "spring",
  stiffness: 400,
  damping: 20,
  mass: 0.3,
} as const;

export default function AnimatedGlassButton({
  children,
  onClick,
  variant = "primary",
  size = "md",
  className = "",
  disabled = false,
}: AnimatedGlassButtonProps) {
  const baseStyles = `
    relative overflow-hidden
    backdrop-blur-2xl 
    border-2 
    disabled:opacity-50 disabled:cursor-not-allowed
  `;
  
  const variantStyles = {
    primary: `
      bg-gradient-to-br from-indigo-400/85 via-purple-400/80 to-violet-500/85
      text-white border-white/40
      shadow-[0_8px_32px_rgba(99,102,241,0.25),0_16px_64px_rgba(139,92,246,0.15),inset_0_2px_4px_rgba(255,255,255,0.6),inset_0_-2px_4px_rgba(0,0,0,0.1)]
    `,
    secondary: `
      bg-gradient-to-br from-white/75 via-white/65 to-white/55
      border-white/60
      text-gray-700
      shadow-[0_6px_24px_rgba(0,0,0,0.06),0_12px_48px_rgba(0,0,0,0.04),inset_0_2px_4px_rgba(255,255,255,0.9),inset_0_-2px_4px_rgba(0,0,0,0.05)]
    `,
    danger: `
      bg-gradient-to-br from-rose-400/80 via-pink-400/75 to-red-400/80
      text-white border-white/40
      shadow-[0_8px_32px_rgba(244,63,94,0.25),0_16px_64px_rgba(251,113,133,0.15),inset_0_2px_4px_rgba(255,255,255,0.6),inset_0_-2px_4px_rgba(0,0,0,0.1)]
    `,
    success: `
      bg-gradient-to-br from-emerald-400/80 via-teal-400/75 to-green-400/80
      text-white border-white/40
      shadow-[0_8px_32px_rgba(52,211,153,0.25),0_16px_64px_rgba(45,212,191,0.15),inset_0_2px_4px_rgba(255,255,255,0.6),inset_0_-2px_4px_rgba(0,0,0,0.1)]
    `,
    icon: `
      bg-gradient-to-br from-white/75 via-white/65 to-white/55
      border-white/60
      text-gray-700
      shadow-[0_6px_24px_rgba(0,0,0,0.06),0_12px_48px_rgba(0,0,0,0.04),inset_0_2px_4px_rgba(255,255,255,0.9),inset_0_-2px_4px_rgba(0,0,0,0.05)]
    `,
  };
  
  const sizeStyles = {
    sm: "px-5 py-2.5 text-sm rounded-full",
    md: "px-7 py-3.5 rounded-full",
    lg: "px-9 py-4.5 text-lg rounded-full",
  };

  return (
    <motion.button
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
      whileHover={!disabled ? { 
        scale: 1.05,
        y: -2,
      } : {}}
      whileTap={!disabled ? { 
        scale: 0.96,
        y: 1,
      } : {}}
      transition={springConfig}
    >
      {/* 顶部高光层 - 鹅卵石顶部亮面效果 */}
      <motion.div 
        className="absolute inset-0 rounded-full pointer-events-none"
        style={{
          background: 'linear-gradient(to bottom, rgba(255,255,255,0.4) 0%, transparent 50%)',
        }}
      />
      
      {/* 按钮内容 */}
      <motion.span 
        className="relative z-10"
        initial={{ opacity: 0, y: 4 }}
        animate={{ opacity: 1, y: 0 }}
        transition={lightSpringConfig}
      >
        {children}
      </motion.span>
    </motion.button>
  );
}
