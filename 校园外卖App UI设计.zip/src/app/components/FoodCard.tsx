import GlassCard from "./GlassCard";

interface FoodCardProps {
  name: string;
  image: string;
  price: number;
  sales?: number;
}

export default function FoodCard({ name, image, price, sales }: FoodCardProps) {
  return (
    <GlassCard className="overflow-hidden hover:scale-[1.03] hover:-translate-y-1 transition-all duration-300 cursor-pointer group">
      <div className="relative h-40 overflow-hidden rounded-t-[1.75rem]">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        {/* 图片顶部渐变遮罩 */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* 图片上的玻璃质感装饰 */}
        <div className="absolute top-0 left-0 right-0 h-1/3 bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
      </div>
      
      <div className="p-4 relative">
        <h4 className="mb-2 relative z-10">{name}</h4>
        <div className="flex items-center justify-between relative z-10">
          <span className="text-orange-500 font-semibold text-lg">¥{price}</span>
          {sales && (
            <span className="text-xs text-gray-400 bg-white/50 backdrop-blur-sm px-2.5 py-1 rounded-full border border-white/60">
              已售 {sales}
            </span>
          )}
        </div>
      </div>
    </GlassCard>
  );
}
