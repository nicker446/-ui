import { ReactNode } from "react";

interface GlassButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "danger" | "success" | "icon";
  size?: "sm" | "md" | "lg";
  className?: string;
  disabled?: boolean;
}

export default function GlassButton({
  children,
  onClick,
  variant = "primary",
  size = "md",
  className = "",
  disabled = false,
}: GlassButtonProps) {
  const baseStyles = `
    relative overflow-hidden
    backdrop-blur-2xl 
    border-2 
    transition-all duration-300 
    disabled:opacity-50 disabled:cursor-not-allowed
    active:scale-[0.98]
  `;
  
  const variantStyles = {
    primary: `
      bg-gradient-to-br from-indigo-400/85 via-purple-400/80 to-violet-500/85
      hover:from-indigo-400/95 hover:via-purple-400/90 hover:to-violet-500/95
      text-white border-white/40
      shadow-[0_8px_32px_rgba(99,102,241,0.25),0_16px_64px_rgba(139,92,246,0.15),inset_0_2px_4px_rgba(255,255,255,0.6),inset_0_-2px_4px_rgba(0,0,0,0.1)]
      hover:shadow-[0_12px_40px_rgba(99,102,241,0.35),0_20px_72px_rgba(139,92,246,0.25),inset_0_2px_6px_rgba(255,255,255,0.8),inset_0_-2px_6px_rgba(0,0,0,0.15)]
    `,
    secondary: `
      bg-gradient-to-br from-white/75 via-white/65 to-white/55
      hover:from-white/85 hover:via-white/75 hover:to-white/65
      border-white/60
      text-gray-700 hover:text-gray-900
      shadow-[0_6px_24px_rgba(0,0,0,0.06),0_12px_48px_rgba(0,0,0,0.04),inset_0_2px_4px_rgba(255,255,255,0.9),inset_0_-2px_4px_rgba(0,0,0,0.05)]
      hover:shadow-[0_8px_32px_rgba(0,0,0,0.08),0_16px_56px_rgba(0,0,0,0.06),inset_0_2px_6px_rgba(255,255,255,1),inset_0_-2px_6px_rgba(0,0,0,0.08)]
    `,
    danger: `
      bg-gradient-to-br from-rose-400/80 via-pink-400/75 to-red-400/80
      hover:from-rose-400/90 hover:via-pink-400/85 hover:to-red-400/90
      text-white border-white/40
      shadow-[0_8px_32px_rgba(244,63,94,0.25),0_16px_64px_rgba(251,113,133,0.15),inset_0_2px_4px_rgba(255,255,255,0.6),inset_0_-2px_4px_rgba(0,0,0,0.1)]
      hover:shadow-[0_12px_40px_rgba(244,63,94,0.35),0_20px_72px_rgba(251,113,133,0.25),inset_0_2px_6px_rgba(255,255,255,0.8),inset_0_-2px_6px_rgba(0,0,0,0.15)]
    `,
    success: `
      bg-gradient-to-br from-emerald-400/80 via-teal-400/75 to-green-400/80
      hover:from-emerald-400/90 hover:via-teal-400/85 hover:to-green-400/90
      text-white border-white/40
      shadow-[0_8px_32px_rgba(52,211,153,0.25),0_16px_64px_rgba(45,212,191,0.15),inset_0_2px_4px_rgba(255,255,255,0.6),inset_0_-2px_4px_rgba(0,0,0,0.1)]
      hover:shadow-[0_12px_40px_rgba(52,211,153,0.35),0_20px_72px_rgba(45,212,191,0.25),inset_0_2px_6px_rgba(255,255,255,0.8),inset_0_-2px_6px_rgba(0,0,0,0.15)]
    `,
    icon: `
      bg-gradient-to-br from-white/75 via-white/65 to-white/55
      hover:from-white/85 hover:via-white/75 hover:to-white/65
      border-white/60
      text-gray-700 hover:text-gray-900
      shadow-[0_6px_24px_rgba(0,0,0,0.06),0_12px_48px_rgba(0,0,0,0.04),inset_0_2px_4px_rgba(255,255,255,0.9),inset_0_-2px_4px_rgba(0,0,0,0.05)]
      hover:shadow-[0_8px_32px_rgba(0,0,0,0.08),0_16px_56px_rgba(0,0,0,0.06),inset_0_2px_6px_rgba(255,255,255,1),inset_0_-2px_6px_rgba(0,0,0,0.08)]
    `,
  };
  
  const sizeStyles = {
    sm: "px-5 py-2.5 text-sm rounded-full",
    md: "px-7 py-3.5 rounded-full",
    lg: "px-9 py-4.5 text-lg rounded-full",
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
    >
      {/* 顶部高光层 - 鹅卵石顶部亮面效果 */}
      <div 
        className="absolute inset-0 rounded-full pointer-events-none"
        style={{
          background: 'linear-gradient(to bottom, rgba(255,255,255,0.4) 0%, transparent 50%)',
        }}
      />
      
      {/* 按钮内容 */}
      <span className="relative z-10">{children}</span>
    </button>
  );
}
