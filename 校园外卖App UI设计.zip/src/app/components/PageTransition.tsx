import { ReactNode } from "react";
import { motion } from "motion/react";

interface PageTransitionProps {
  children: ReactNode;
}

// iOS风格的弹簧动画配置
const springConfig = {
  type: "spring",
  stiffness: 380,
  damping: 30,
  mass: 0.8,
} as const;

// 页面进入/退出动画变体
const pageVariants = {
  initial: {
    opacity: 0,
    x: 20,
    scale: 0.98,
  },
  animate: {
    opacity: 1,
    x: 0,
    scale: 1,
  },
  exit: {
    opacity: 0,
    x: -20,
    scale: 0.98,
  },
};

export default function PageTransition({ children }: PageTransitionProps) {
  return (
    <motion.div
      initial="initial"
      animate="animate"
      exit="exit"
      variants={pageVariants}
      transition={springConfig}
      className="min-h-screen"
    >
      {children}
    </motion.div>
  );
}
