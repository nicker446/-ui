import { ReactNode } from "react";
import { motion } from "motion/react";

interface GlassIconButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "danger";
  size?: "sm" | "md" | "lg";
  className?: string;
}

// iOS风格的弹簧动画配置
const springConfig = {
  type: "spring",
  stiffness: 500,
  damping: 25,
  mass: 0.5,
} as const;

export default function GlassIconButton({
  children,
  onClick,
  variant = "secondary",
  size = "md",
  className = "",
}: GlassIconButtonProps) {
  const baseStyles = `
    relative overflow-hidden
    backdrop-blur-2xl 
    border-2 
    transition-colors
    flex items-center justify-center
  `;
  
  const variantStyles = {
    primary: `
      bg-gradient-to-br from-indigo-400/85 via-purple-400/80 to-violet-500/85
      text-white border-white/40
      shadow-[0_6px_24px_rgba(99,102,241,0.25),0_12px_48px_rgba(139,92,246,0.15),inset_0_2px_4px_rgba(255,255,255,0.6),inset_0_-2px_4px_rgba(0,0,0,0.1)]
    `,
    secondary: `
      bg-gradient-to-br from-white/75 via-white/65 to-white/55
      border-white/60
      text-gray-700
      shadow-[0_4px_16px_rgba(0,0,0,0.06),0_8px_32px_rgba(0,0,0,0.04),inset_0_2px_4px_rgba(255,255,255,0.9),inset_0_-2px_4px_rgba(0,0,0,0.05)]
    `,
    danger: `
      bg-gradient-to-br from-rose-400/80 via-pink-400/75 to-red-400/80
      text-white border-white/40
      shadow-[0_6px_24px_rgba(244,63,94,0.25),0_12px_48px_rgba(251,113,133,0.15),inset_0_2px_4px_rgba(255,255,255,0.6),inset_0_-2px_4px_rgba(0,0,0,0.1)]
    `,
  };
  
  const sizeStyles = {
    sm: "w-8 h-8 rounded-[1rem]",
    md: "w-11 h-11 rounded-[1.25rem]",
    lg: "w-14 h-14 rounded-[1.5rem]",
  };

  return (
    <motion.button
      onClick={onClick}
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
      whileHover={{ 
        scale: 1.15,
        y: -2,
        rotate: 5,
      }}
      whileTap={{ 
        scale: 0.95,
        y: 0,
        rotate: 0,
      }}
      transition={springConfig}
    >
      {/* 顶部高光层 - 鹅卵石顶部亮面效果 */}
      <div 
        className="absolute inset-0 rounded-[inherit] pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at top, rgba(255,255,255,0.6) 0%, transparent 60%)',
        }}
      />
      
      {/* 图标内容 */}
      <motion.div
        className="relative z-10"
        whileHover={{ rotate: 360 }}
        transition={{ duration: 0.5, ease: "easeInOut" }}
      >
        {children}
      </motion.div>
    </motion.button>
  );
}