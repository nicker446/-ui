import { ReactNode } from "react";

interface TechBackgroundProps {
  children: ReactNode;
  className?: string;
}

export default function TechBackground({ children, className = "" }: TechBackgroundProps) {
  return (
    <div className={`min-h-screen relative overflow-hidden ${className}`}>
      {/* 主渐变背景 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100" />
      
      {/* 次级渐变叠加 */}
      <div className="fixed inset-0 bg-gradient-to-tr from-blue-50/50 via-transparent to-orange-50/50" />
      
      {/* 几何图案层 */}
      <div className="fixed inset-0 opacity-40">
        {/* 网格图案 */}
        <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <circle cx="30" cy="30" r="1.5" fill="#818cf8" opacity="0.3" />
            </pattern>
            <pattern id="dots" width="40" height="40" patternUnits="userSpaceOnUse">
              <circle cx="20" cy="20" r="1" fill="#c084fc" opacity="0.4" />
            </pattern>
            <pattern id="squares" width="80" height="80" patternUnits="userSpaceOnUse">
              <rect x="39" y="39" width="2" height="2" fill="#f472b6" opacity="0.25" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          <rect width="100%" height="100%" fill="url(#dots)" />
          <rect width="100%" height="100%" fill="url(#squares)" />
        </svg>
      </div>
      
      {/* 装饰性几何形状 */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {/* 左上圆形 */}
        <div className="absolute -top-40 -left-40 w-80 h-80 rounded-full bg-gradient-to-br from-indigo-300/20 to-purple-300/20 blur-3xl" />
        
        {/* 右上圆形 */}
        <div className="absolute -top-20 right-20 w-96 h-96 rounded-full bg-gradient-to-br from-purple-300/15 to-pink-300/15 blur-3xl" />
        
        {/* 左下圆形 */}
        <div className="absolute -bottom-40 -left-20 w-96 h-96 rounded-full bg-gradient-to-br from-blue-300/20 to-indigo-300/20 blur-3xl" />
        
        {/* 右下圆形 */}
        <div className="absolute -bottom-20 -right-40 w-80 h-80 rounded-full bg-gradient-to-br from-pink-300/15 to-orange-300/15 blur-3xl" />
        
        {/* 中心光晕 */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-gradient-to-br from-purple-200/10 via-transparent to-transparent blur-3xl" />
      </div>
      
      {/* 内容层 */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}
