import { Home, Grid3x3, ShoppingBag, User } from "lucide-react";
import { Link, useLocation } from "react-router";
import { motion } from "motion/react";

export default function BottomNav() {
  const location = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "首页" },
    { path: "/categories", icon: Grid3x3, label: "分类" },
    { path: "/orders", icon: ShoppingBag, label: "订单" },
    { path: "/profile", icon: User, label: "我的" },
  ];

  // iOS风格的弹簧动画配置
  const springConfig = {
    type: "spring",
    stiffness: 400,
    damping: 25,
    mass: 0.6,
  } as const;

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 z-50 border-t-2 border-white/60"
      style={{
        background: 'linear-gradient(to bottom, rgba(255,255,255,0.85) 0%, rgba(255,255,255,0.75) 100%)',
        backdropFilter: 'blur(32px)',
        boxShadow: `
          0 -8px 32px rgba(0, 0, 0, 0.06),
          0 -16px 64px rgba(0, 0, 0, 0.04),
          inset 0 2px 4px rgba(255, 255, 255, 0.9),
          inset 0 -1px 2px rgba(0, 0, 0, 0.03)
        `,
      }}
    >
      {/* 顶部高光 */}
      <div 
        className="absolute inset-x-0 top-0 h-1/2 pointer-events-none"
        style={{
          background: 'linear-gradient(to bottom, rgba(255,255,255,0.5) 0%, transparent 100%)',
        }}
      />
      
      <div className="max-w-screen-xl mx-auto px-6 py-3 relative z-10">
        <div className="flex justify-around items-center">
          {navItems.map((item, index) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className="relative flex flex-col items-center gap-1.5 group"
              >
                {/* 激活状态的玻璃质感背景 - 添加动画 */}
                {isActive && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute -inset-3 rounded-[1.25rem] border-2 border-white/60 -z-10"
                    style={{
                      background: 'linear-gradient(135deg, rgba(99,102,241,0.15) 0%, rgba(139,92,246,0.1) 100%)',
                      backdropFilter: 'blur(16px)',
                      boxShadow: `
                        0 4px 16px rgba(99, 102, 241, 0.15),
                        0 8px 32px rgba(139, 92, 246, 0.1),
                        inset 0 1px 2px rgba(255, 255, 255, 0.8),
                        inset 0 -1px 2px rgba(99, 102, 241, 0.1)
                      `,
                    }}
                    transition={springConfig}
                  />
                )}
                
                <motion.div 
                  className={`
                    p-2.5 rounded-2xl
                    ${isActive 
                      ? 'text-indigo-600' 
                      : 'text-gray-500'
                    }
                  `}
                  whileHover={{ scale: 1.15, y: -2 }}
                  whileTap={{ scale: 0.95, y: 0 }}
                  animate={isActive ? { 
                    scale: 1.1,
                    transition: springConfig,
                  } : {
                    scale: 1,
                  }}
                  transition={springConfig}
                >
                  <motion.div
                    animate={isActive ? {
                      rotate: 0,
                      transition: {
                        duration: 0.6,
                        ease: "easeInOut",
                      }
                    } : {}}
                  >
                    <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
                  </motion.div>
                </motion.div>
                
                <motion.span 
                  className={`
                    text-xs font-medium
                    ${isActive ? 'text-indigo-600' : 'text-gray-500'}
                  `}
                  animate={isActive ? {
                    scale: 1.05,
                  } : {
                    scale: 1,
                  }}
                  transition={springConfig}
                >
                  {item.label}
                </motion.span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}