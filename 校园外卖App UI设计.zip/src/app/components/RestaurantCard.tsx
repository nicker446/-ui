import { Star, Clock } from "lucide-react";
import GlassCard from "./GlassCard";

interface RestaurantCardProps {
  name: string;
  image: string;
  rating: number;
  deliveryTime: string;
  minOrder: number;
  category: string;
}

export default function RestaurantCard({
  name,
  image,
  rating,
  deliveryTime,
  minOrder,
  category,
}: RestaurantCardProps) {
  return (
    <GlassCard className="overflow-hidden hover:scale-[1.03] hover:-translate-y-1 transition-all duration-300 cursor-pointer group">
      <div className="relative h-48 overflow-hidden rounded-t-[1.75rem]">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        {/* 图片渐变遮罩 */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-black/10 to-white/10" />
        
        {/* 图片顶部高光 */}
        <div className="absolute top-0 left-0 right-0 h-1/3 bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
        
        {/* 评分标签 - 玻璃质感 */}
        <div 
          className="absolute top-4 right-4 text-white px-3.5 py-2 rounded-full text-sm flex items-center gap-1.5 border-2 border-white/40 backdrop-blur-2xl"
          style={{
            background: 'linear-gradient(135deg, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0.3) 100%)',
            boxShadow: '0 4px 16px rgba(0,0,0,0.2), inset 0 1px 2px rgba(255,255,255,0.3), inset 0 -1px 2px rgba(0,0,0,0.2)',
          }}
        >
          <Star size={14} fill="currentColor" className="text-yellow-300" />
          <span className="font-semibold">{rating}</span>
        </div>
      </div>
      
      <div className="p-5 relative">
        <h3 className="text-lg mb-1 relative z-10">{name}</h3>
        <p className="text-sm text-gray-500 mb-3 relative z-10">{category}</p>
        <div className="flex items-center justify-between text-sm text-gray-600 relative z-10">
          <div className="flex items-center gap-1.5 bg-white/40 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/50">
            <Clock size={16} />
            <span>{deliveryTime}</span>
          </div>
          <span className="bg-white/40 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/50">
            起送 ¥{minOrder}
          </span>
        </div>
      </div>
    </GlassCard>
  );
}
