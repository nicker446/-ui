import { Clock, CheckCircle, Package } from "lucide-react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import BottomNav from "../components/BottomNav";
import AnimatedGlassCard from "../components/AnimatedGlassCard";
import PageTransition from "../components/PageTransition";
import TechBackground from "../components/TechBackground";
import { springConfig, fadeInUp, fadeInLeft } from "../utils/animations";

export default function Orders() {
  const navigate = useNavigate();

  const orders = [
    {
      id: "202602280001",
      restaurantName: "精致汉堡工坊",
      items: ["经典芝士堡", "薯条", "可乐"],
      total: 58,
      status: "delivering",
      time: "今天 12:30",
      image: "https://images.unsplash.com/photo-1558250070-363aa42f9a00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWxpY2lvdXMlMjBidXJnZXIlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXx8fHwxNzcyMjIyNDcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      id: "202602270023",
      restaurantName: "和风寿司料理",
      items: ["三文鱼寿司", "天妇罗"],
      total: 88,
      status: "completed",
      time: "昨天 19:15",
      image: "https://images.unsplash.com/photo-1630748662890-11623a758d6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwc3VzaGklMjBwbGF0dGVyJTIwamFwYW5lc2V8ZW58MXx8fHwxNzcyMTgxMTY1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      id: "202602260015",
      restaurantName: "意式披萨屋",
      items: ["玛格丽特披萨", "凯撒沙拉"],
      total: 72,
      status: "completed",
      time: "2月26日 13:45",
      image: "https://images.unsplash.com/photo-1763478156969-4d7c0ab35590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpc2FuJTIwcGl6emElMjBpdGFsaWFuJTIwY3Vpc2luZXxlbnwxfHx8fDE3NzIyODY4MTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
  ];

  const getStatusInfo = (status: string) => {
    switch (status) {
      case "delivering":
        return {
          icon: Package,
          text: "配送中",
          color: "text-blue-600",
          bgColor: "bg-blue-100",
        };
      case "completed":
        return {
          icon: CheckCircle,
          text: "已完成",
          color: "text-green-600",
          bgColor: "bg-green-100",
        };
      default:
        return {
          icon: Clock,
          text: "待处理",
          color: "text-orange-600",
          bgColor: "bg-orange-100",
        };
    }
  };

  return (
    <PageTransition>
      <TechBackground>
        {/* Header */}
        <motion.div 
          className="px-6 pt-8 pb-6"
          {...fadeInUp}
          transition={{ ...springConfig, delay: 0.1 }}
        >
          <h1 className="text-2xl mb-2">我的订单</h1>
          <p className="text-gray-500">查看您的历史订单</p>
        </motion.div>

        {/* Orders List */}
        <div className="px-6 space-y-4">
          {orders.map((order, index) => {
            const statusInfo = getStatusInfo(order.status);
            const StatusIcon = statusInfo.icon;
            
            return (
              <AnimatedGlassCard 
                key={order.id} 
                className="p-5 cursor-pointer"
                onClick={() => navigate(`/order?id=${order.id}`)}
                delay={0.2 + index * 0.1}
              >
                <div className="flex gap-4">
                  <motion.div 
                    className="w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ ...springConfig, delay: 0.3 + index * 0.1 }}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    <img
                      src={order.image}
                      alt={order.restaurantName}
                      className="w-full h-full object-cover"
                    />
                  </motion.div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <motion.h3 
                        className="truncate"
                        {...fadeInLeft}
                        transition={{ ...springConfig, delay: 0.4 + index * 0.1 }}
                      >
                        {order.restaurantName}
                      </motion.h3>
                      <motion.div 
                        className={`${statusInfo.bgColor} ${statusInfo.color} px-3 py-1 rounded-full text-xs flex items-center gap-1 flex-shrink-0 ml-2`}
                        initial={{ opacity: 0, scale: 0 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ ...springConfig, delay: 0.5 + index * 0.1 }}
                        whileHover={{ scale: 1.1 }}
                      >
                        <motion.div
                          animate={order.status === "delivering" ? {
                            rotate: 360,
                            transition: {
                              duration: 2,
                              repeat: Infinity,
                              ease: "linear",
                            }
                          } : {}}
                        >
                          <StatusIcon size={12} />
                        </motion.div>
                        {statusInfo.text}
                      </motion.div>
                    </div>
                    <motion.p 
                      className="text-sm text-gray-500 mb-2 truncate"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.5 + index * 0.1 }}
                    >
                      {order.items.join(" · ")}
                    </motion.p>
                    <motion.div 
                      className="flex items-center justify-between"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.6 + index * 0.1 }}
                    >
                      <span className="text-sm text-gray-400">{order.time}</span>
                      <motion.span 
                        className="font-medium"
                        whileHover={{ scale: 1.1 }}
                      >
                        ¥{order.total}
                      </motion.span>
                    </motion.div>
                  </div>
                </div>
              </AnimatedGlassCard>
            );
          })}
        </div>

        {/* 添加底部间距，避免被导航栏遮挡 */}
        <div className="h-24" />

        <BottomNav />
      </TechBackground>
    </PageTransition>
  );
}