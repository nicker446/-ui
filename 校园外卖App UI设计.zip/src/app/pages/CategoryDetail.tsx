import { ArrowLeft } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router";
import RestaurantCard from "../components/RestaurantCard";
import { getRestaurantsByCategory } from "../data/restaurants";
import { popularCategories } from "../data/categories";
import TechBackground from "../components/TechBackground";

export default function CategoryDetail() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const categoryId = searchParams.get("id") || "";
  const categoryName = searchParams.get("name") || "美食分类";
  
  const restaurants = getRestaurantsByCategory(categoryId);
  const category = popularCategories.find(c => c.id === categoryId);

  return (
    <TechBackground>
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-4 mb-2">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/60 backdrop-blur-md rounded-full flex items-center justify-center"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl">{categoryName}</h1>
        </div>
        {category?.description && (
          <p className="text-gray-500 ml-14 mb-2">{category.description}</p>
        )}
        <p className="text-gray-500 ml-14">{restaurants.length} 家商户</p>
      </div>

      {/* Restaurants List */}
      <div className="px-6 space-y-4">
        {restaurants.length > 0 ? (
          restaurants.map((restaurant) => (
            <div key={restaurant.id} onClick={() => navigate(`/restaurant?id=${restaurant.id}`)}>
              <RestaurantCard {...restaurant} />
            </div>
          ))
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-400">暂无商户</p>
          </div>
        )}
      </div>
    </TechBackground>
  );
}