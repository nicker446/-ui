import { ArrowLeft, Heart } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";
import RestaurantCard from "../components/RestaurantCard";
import TechBackground from "../components/TechBackground";

export default function Favorites() {
  const navigate = useNavigate();
  const [favorites, setFavorites] = useState([
    {
      id: "1",
      name: "精致汉堡工坊",
      image: "https://images.unsplash.com/photo-1558250070-363aa42f9a00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWxpY2lvdXMlMjBidXJnZXIlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXx8fHwxNzcyMjIyNDcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.8,
      deliveryTime: "25-35分钟",
      minOrder: 20,
      category: "西式快餐",
    },
    {
      id: "2",
      name: "和风寿司料理",
      image: "https://images.unsplash.com/photo-1630748662890-11623a758d6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwc3VzaGklMjBwbGF0dGVyJTIwamFwYW5lc2V8ZW58MXx8fHwxNzcyMTgxMTY1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.9,
      deliveryTime: "30-40分钟",
      minOrder: 35,
      category: "日式料理",
    },
    {
      id: "3",
      name: "意式披萨屋",
      image: "https://images.unsplash.com/photo-1763478156969-4d7c0ab35590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpc2FuJTIwcGl6emElMjBpdGFsaWFuJTIwY3Vpc2luZXxlbnwxfHx8fDE3NzIyODY4MTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.7,
      deliveryTime: "20-30分钟",
      minOrder: 25,
      category: "西式简餐",
    },
  ]);

  return (
    <TechBackground>
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-4 mb-2">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/60 backdrop-blur-md rounded-full flex items-center justify-center"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl">我的收藏</h1>
        </div>
        <p className="text-gray-500 ml-14">{favorites.length} 家商户</p>
      </div>

      {/* Favorites List */}
      <div className="px-6 space-y-4">
        {favorites.length > 0 ? (
          favorites.map((restaurant) => (
            <div key={restaurant.id} onClick={() => navigate(`/restaurant?id=${restaurant.id}`)}>
              <RestaurantCard {...restaurant} />
            </div>
          ))
        ) : (
          <div className="text-center py-20">
            <Heart size={64} className="text-gray-300 mx-auto mb-4" />
            <p className="text-gray-400">暂无收藏</p>
          </div>
        )}
      </div>
    </TechBackground>
  );
}