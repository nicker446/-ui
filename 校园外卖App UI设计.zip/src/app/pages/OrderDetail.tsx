import { ArrowLeft, MapPin, Clock, Phone, CheckCircle, Truck } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router";
import GlassCard from "../components/GlassCard";
import TechBackground from "../components/TechBackground";

export default function OrderDetail() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get("id") || "202602280001";

  const order = {
    id: orderId,
    restaurantName: "精致汉堡工坊",
    status: "delivering",
    items: [
      { name: "经典芝士堡", quantity: 2, price: 28 },
      { name: "薯条", quantity: 1, price: 12 },
      { name: "可乐", quantity: 1, price: 8 },
    ],
    subtotal: 76,
    deliveryFee: 5,
    discount: -8,
    total: 73,
    address: "校园1号楼 302室",
    contact: "李明",
    phone: "138****8888",
    orderTime: "2026-02-28 12:30",
    estimatedTime: "13:00-13:15",
    timeline: [
      { time: "12:30", label: "订单已提交", icon: CheckCircle, completed: true },
      { time: "12:35", label: "商家已接单", icon: CheckCircle, completed: true },
      { time: "12:45", label: "骑手已取餐", icon: CheckCircle, completed: true },
      { time: "13:05", label: "配送中", icon: CheckCircle, completed: false },
      { time: "13:15", label: "送达", icon: CheckCircle, completed: false },
    ],
  };

  return (
    <TechBackground>
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/60 backdrop-blur-md rounded-full flex items-center justify-center"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl">订单详情</h1>
        </div>
      </div>

      {/* Status */}
      <div className="px-6 mb-6">
        <GlassCard className="p-6 bg-gradient-to-br from-blue-500/10 to-purple-500/10">
          <div className="flex items-center gap-3 mb-3">
            <Truck size={24} className="text-blue-600" />
            <div>
              <h2 className="text-xl">配送中</h2>
              <p className="text-sm text-gray-500">预计 {order.estimatedTime} 送达</p>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Timeline */}
      <div className="px-6 mb-6">
        <h2 className="text-xl mb-4">订单进度</h2>
        <GlassCard className="p-5">
          <div className="space-y-4">
            {order.timeline.map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        item.completed
                          ? "bg-blue-500 text-white"
                          : "bg-gray-200 text-gray-400"
                      }`}
                    >
                      <Icon size={16} />
                    </div>
                    {index < order.timeline.length - 1 && (
                      <div
                        className={`w-0.5 h-8 my-1 ${
                          item.completed ? "bg-blue-500" : "bg-gray-200"
                        }`}
                      />
                    )}
                  </div>
                  <div className="flex-1 pb-4">
                    <div className={item.completed ? "" : "text-gray-400"}>
                      {item.label}
                    </div>
                    <div className="text-sm text-gray-500">{item.time}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </GlassCard>
      </div>

      {/* Delivery Info */}
      <div className="px-6 mb-6">
        <h2 className="text-xl mb-4">配送信息</h2>
        <GlassCard className="p-5">
          <div className="flex items-start gap-3 mb-4">
            <MapPin size={20} className="text-gray-600 mt-0.5" />
            <div className="flex-1">
              <div className="mb-1">{order.address}</div>
              <div className="text-sm text-gray-500">
                {order.contact} {order.phone}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3 pt-4 border-t border-gray-200/50">
            <Phone size={20} className="text-gray-600" />
            <div className="flex-1">联系骑手</div>
            <button className="text-blue-600 text-sm">拨打电话</button>
          </div>
        </GlassCard>
      </div>

      {/* Order Items */}
      <div className="px-6 mb-6">
        <h2 className="text-xl mb-4">订单商品</h2>
        <GlassCard className="p-5">
          <div className="mb-4">
            <h3 className="">{order.restaurantName}</h3>
          </div>
          <div className="space-y-3 mb-4">
            {order.items.map((item, index) => (
              <div key={index} className="flex items-center justify-between text-sm">
                <span className="text-gray-600">
                  {item.name} x{item.quantity}
                </span>
                <span>¥{item.price * item.quantity}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-gray-200/50 pt-4 space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">商品小计</span>
              <span>¥{order.subtotal}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">配送费</span>
              <span>¥{order.deliveryFee}</span>
            </div>
            {order.discount < 0 && (
              <div className="flex items-center justify-between text-orange-500">
                <span>优惠</span>
                <span>¥{order.discount}</span>
              </div>
            )}
            <div className="flex items-center justify-between pt-2 border-t border-gray-200/50">
              <span className="">实付</span>
              <span className="text-xl text-orange-500">¥{order.total}</span>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Order Info */}
      <div className="px-6">
        <h2 className="text-xl mb-4">订单信息</h2>
        <GlassCard className="p-5">
          <div className="space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">订单编号</span>
              <span>{order.id}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">下单时间</span>
              <span>{order.orderTime}</span>
            </div>
          </div>
        </GlassCard>
      </div>
    </TechBackground>
  );
}