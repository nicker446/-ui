import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";
import RestaurantCard from "../components/RestaurantCard";
import { restaurants } from "../data/restaurants";
import GlassButton from "../components/GlassButton";
import TechBackground from "../components/TechBackground";

export default function AllRestaurants() {
  const navigate = useNavigate();
  const [sortBy, setSortBy] = useState("推荐");

  const sortOptions = ["推荐", "评分最高", "距离最近", "起送最低"];

  return (
    <TechBackground>
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/60 backdrop-blur-md rounded-full flex items-center justify-center"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl">全部商家</h1>
        </div>

        {/* Sort Options */}
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {sortOptions.map((option) => (
            <GlassButton
              key={option}
              onClick={() => setSortBy(option)}
              variant={sortBy === option ? "primary" : "secondary"}
              size="sm"
              className="flex-shrink-0"
            >
              {option}
            </GlassButton>
          ))}
        </div>
      </div>

      {/* Restaurants List */}
      <div className="px-6">
        <p className="text-gray-500 mb-4">{restaurants.length} 家商户</p>
        <div className="space-y-4">
          {restaurants.map((restaurant) => (
            <div
              key={restaurant.id}
              onClick={() => navigate(`/restaurant?id=${restaurant.id}`)}
            >
              <RestaurantCard {...restaurant} />
            </div>
          ))}
        </div>
      </div>
    </TechBackground>
  );
}