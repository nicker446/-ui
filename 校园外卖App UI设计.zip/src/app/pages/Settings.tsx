import { ArrowLeft, ChevronRight, Bell, Lock, Globe, Moon, Info } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";
import GlassCard from "../components/GlassCard";
import TechBackground from "../components/TechBackground";

export default function Settings() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  const settingGroups = [
    {
      title: "通知设置",
      items: [
        {
          icon: Bell,
          label: "推送通知",
          type: "toggle",
          value: notifications,
          onChange: setNotifications,
        },
      ],
    },
    {
      title: "账号与安全",
      items: [
        { icon: Lock, label: "修改密码", type: "link", path: "#" },
        { icon: Lock, label: "实名认证", type: "link", path: "#" },
      ],
    },
    {
      title: "偏好设置",
      items: [
        { icon: Globe, label: "语言设置", type: "link", value: "简体中文", path: "#" },
        {
          icon: Moon,
          label: "深色模式",
          type: "toggle",
          value: darkMode,
          onChange: setDarkMode,
        },
      ],
    },
    {
      title: "关于",
      items: [
        { icon: Info, label: "关于我们", type: "link", path: "#" },
        { icon: Info, label: "隐私政策", type: "link", path: "#" },
        { icon: Info, label: "用户协议", type: "link", path: "#" },
      ],
    },
  ];

  return (
    <TechBackground>
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/60 backdrop-blur-md rounded-full flex items-center justify-center"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl">账号设置</h1>
        </div>
      </div>

      {/* Settings Groups */}
      <div className="px-6 space-y-6">
        {settingGroups.map((group, groupIndex) => (
          <div key={groupIndex}>
            <h2 className="text-sm text-gray-500 mb-3 ml-2">{group.title}</h2>
            <GlassCard className="overflow-hidden">
              {group.items.map((item, itemIndex) => {
                const Icon = item.icon;
                return (
                  <div key={itemIndex}>
                    <button
                      onClick={() => item.path && navigate(item.path)}
                      className="w-full flex items-center gap-4 p-5 hover:bg-white/30 transition-colors"
                    >
                      <Icon size={22} className="text-gray-600" />
                      <span className="flex-1 text-left">{item.label}</span>
                      {item.type === "toggle" ? (
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            item.onChange?.(!item.value);
                          }}
                          className={`w-12 h-6 rounded-full transition-colors cursor-pointer ${
                            item.value ? "bg-blue-500" : "bg-gray-300"
                          }`}
                        >
                          <div
                            className={`w-5 h-5 bg-white rounded-full transition-transform ${
                              item.value ? "translate-x-6" : "translate-x-0.5"
                            } mt-0.5`}
                          />
                        </div>
                      ) : (
                        <>
                          {item.value && (
                            <span className="text-sm text-gray-400">{item.value}</span>
                          )}
                          <ChevronRight size={20} className="text-gray-400" />
                        </>
                      )}
                    </button>
                    {itemIndex < group.items.length - 1 && (
                      <div className="mx-5 border-t border-gray-200/50" />
                    )}
                  </div>
                );
              })}
            </GlassCard>
          </div>
        ))}
      </div>

      {/* Logout Button */}
      <div className="px-6 mt-8">
        <button className="w-full bg-white/60 backdrop-blur-md border border-white/50 rounded-3xl p-5 text-red-500 hover:scale-[1.01] transition-transform">
          退出登录
        </button>
      </div>
    </TechBackground>
  );
}