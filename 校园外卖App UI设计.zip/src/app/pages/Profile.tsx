import { MapPin, Heart, Settings, HelpCircle, LogOut, ChevronRight, Gift, CreditCard } from "lucide-react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import BottomNav from "../components/BottomNav";
import AnimatedGlassCard from "../components/AnimatedGlassCard";
import PageTransition from "../components/PageTransition";
import TechBackground from "../components/TechBackground";

export default function Profile() {
  const navigate = useNavigate();

  // iOS风格的弹簧动画配置
  const springConfig = {
    type: "spring",
    stiffness: 380,
    damping: 28,
    mass: 0.5,
  } as const;

  const stats = [
    { label: "优惠券", value: "5", icon: Gift, path: "/coupons" },
    { label: "收藏", value: "23", icon: Heart, path: "/favorites" },
    { label: "余额", value: "¥128", icon: CreditCard, path: "#" },
  ];

  const menuItems = [
    { icon: MapPin, label: "收货地址", color: "text-blue-600", path: "/address" },
    { icon: Heart, label: "我的收藏", color: "text-pink-600", path: "/favorites" },
    { icon: Settings, label: "账号设置", color: "text-gray-600", path: "/settings" },
    { icon: HelpCircle, label: "帮助中心", color: "text-green-600", path: "/help" },
    { icon: LogOut, label: "退出登录", color: "text-red-600", path: "#" },
  ];

  return (
    <PageTransition>
      <TechBackground>
        {/* Header */}
        <motion.div 
          className="px-6 pt-8 pb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...springConfig, delay: 0.1 }}
        >
          <AnimatedGlassCard className="p-6" delay={0.2}>
            <div className="flex items-center gap-4">
              <motion.div 
                className="relative w-20 h-20 rounded-full bg-gradient-to-br from-indigo-400/85 to-purple-500/85 flex items-center justify-center text-white text-2xl border-2 border-white/40 overflow-hidden"
                style={{
                  boxShadow: `
                    0 6px 24px rgba(99, 102, 241, 0.25),
                    0 12px 48px rgba(139, 92, 246, 0.15),
                    inset 0 2px 4px rgba(255, 255, 255, 0.6),
                    inset 0 -2px 4px rgba(0, 0, 0, 0.15)
                  `,
                }}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ ...springConfig, delay: 0.3 }}
                whileHover={{ scale: 1.1, rotate: 360 }}
              >
                {/* 头像顶部高光 */}
                <div 
                  className="absolute inset-0 rounded-full pointer-events-none"
                  style={{
                    background: 'radial-gradient(ellipse at top, rgba(255,255,255,0.5) 0%, transparent 60%)',
                  }}
                />
                <span className="relative z-10">李</span>
              </motion.div>
              <motion.div 
                className="flex-1"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ ...springConfig, delay: 0.4 }}
              >
                <h2 className="text-xl mb-1">李明</h2>
                <p className="text-sm text-gray-500">学号: 2023010101</p>
              </motion.div>
            </div>
          </AnimatedGlassCard>
        </motion.div>

        {/* Stats */}
        <div className="px-6 mb-6">
          <div className="grid grid-cols-3 gap-4">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <AnimatedGlassCard 
                  key={stat.label} 
                  className="p-4 text-center cursor-pointer group"
                  onClick={() => stat.path !== "#" && navigate(stat.path)}
                  delay={0.5 + index * 0.1}
                >
                  <motion.div 
                    className="w-12 h-12 rounded-[1.25rem] bg-gradient-to-br from-white/80 to-white/60 border-2 border-white/60 flex items-center justify-center mx-auto mb-2 relative overflow-hidden"
                    style={{
                      boxShadow: `
                        0 4px 16px rgba(0, 0, 0, 0.08),
                        0 8px 32px rgba(0, 0, 0, 0.06),
                        inset 0 2px 4px rgba(255, 255, 255, 0.9),
                        inset 0 -2px 4px rgba(0, 0, 0, 0.05)
                      `,
                    }}
                    whileHover={{ 
                      scale: 1.2,
                      rotate: 15,
                      transition: springConfig,
                    }}
                  >
                    {/* 图标容器高光 */}
                    <div 
                      className="absolute inset-0 rounded-[1.25rem] pointer-events-none"
                      style={{
                        background: 'radial-gradient(ellipse at top, rgba(255,255,255,0.8) 0%, transparent 60%)',
                      }}
                    />
                    <Icon size={24} className="text-gray-600 relative z-10" />
                  </motion.div>
                  <motion.div 
                    className="text-lg mb-1 font-semibold text-gray-800"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ ...springConfig, delay: 0.6 + index * 0.1 }}
                  >
                    {stat.value}
                  </motion.div>
                  <div className="text-xs text-gray-500">{stat.label}</div>
                </AnimatedGlassCard>
              );
            })}
          </div>
        </div>

        {/* Menu */}
        <motion.div 
          className="px-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...springConfig, delay: 0.8 }}
        >
          <AnimatedGlassCard className="overflow-hidden" delay={0.9}>
            {menuItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={item.label}>
                  <motion.button 
                    onClick={() => item.path !== "#" && navigate(item.path)}
                    className="w-full flex items-center gap-4 p-5 hover:bg-white/30 transition-colors duration-300 rounded-[1.25rem]"
                    initial={{ opacity: 0, x: -30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ ...springConfig, delay: 1.0 + index * 0.1 }}
                    whileHover={{ 
                      x: 8,
                      transition: springConfig,
                    }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <motion.div
                      whileHover={{ 
                        rotate: item.label === "退出登录" ? 180 : 360,
                        scale: 1.2,
                        transition: { duration: 0.5 },
                      }}
                    >
                      <Icon size={22} className={item.color} />
                    </motion.div>
                    <span className="flex-1 text-left">{item.label}</span>
                    <motion.div
                      whileHover={{ x: 4 }}
                    >
                      <ChevronRight size={20} className="text-gray-400" />
                    </motion.div>
                  </motion.button>
                  {index < menuItems.length - 1 && (
                    <motion.div 
                      className="mx-5 border-t border-gray-200/50"
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 1 }}
                      transition={{ ...springConfig, delay: 1.1 + index * 0.1 }}
                      style={{ originX: 0 }}
                    />
                  )}
                </div>
              );
            })}
          </AnimatedGlassCard>
        </motion.div>

        {/* 添加底部间距，避免被导航栏遮挡 */}
        <div className="h-24" />

        <BottomNav />
      </TechBackground>
    </PageTransition>
  );
}