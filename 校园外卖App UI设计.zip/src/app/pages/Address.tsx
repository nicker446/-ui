import { ArrowLeft, MapPin, Plus } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";
import GlassCard from "../components/GlassCard";
import GlassIconButton from "../components/GlassIconButton";
import GlassButton from "../components/GlassButton";
import TechBackground from "../components/TechBackground";

export default function Address() {
  const navigate = useNavigate();
  const [addresses, setAddresses] = useState([
    {
      id: "1",
      label: "宿舍",
      detail: "校园1号楼 302室",
      contact: "李明",
      phone: "138****8888",
      isDefault: true,
    },
    {
      id: "2",
      label: "教学楼",
      detail: "第二教学楼 A201",
      contact: "李明",
      phone: "138****8888",
      isDefault: false,
    },
    {
      id: "3",
      label: "图书馆",
      detail: "图书馆三楼自习区",
      contact: "李明",
      phone: "138****8888",
      isDefault: false,
    },
  ]);

  const setDefault = (id: string) => {
    setAddresses((addrs) =>
      addrs.map((addr) => ({ ...addr, isDefault: addr.id === id }))
    );
  };

  const deleteAddress = (id: string) => {
    setAddresses((addrs) => addrs.filter((addr) => addr.id !== id));
  };

  return (
    <TechBackground>
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/60 backdrop-blur-md rounded-full flex items-center justify-center"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl">收货地址</h1>
        </div>
      </div>

      {/* Address List */}
      <div className="px-6 space-y-4 mb-6">
        {addresses.map((address) => (
          <GlassCard key={address.id} className="p-5">
            <div className="flex gap-4">
              <GlassIconButton variant="primary" size="md" className="flex-shrink-0">
                <MapPin size={20} />
              </GlassIconButton>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <span className="">{address.label}</span>
                  {address.isDefault && (
                    <span className="bg-orange-100 text-orange-600 text-xs px-2 py-0.5 rounded-full">
                      默认
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-600 mb-1">{address.detail}</p>
                <p className="text-sm text-gray-500">
                  {address.contact} {address.phone}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 mt-4 pt-4 border-t border-gray-200/50">
              {!address.isDefault && (
                <button
                  onClick={() => setDefault(address.id)}
                  className="flex items-center gap-1 text-sm text-gray-600 hover:text-blue-600"
                >
                  <Check size={16} />
                  设为默认
                </button>
              )}
              <button className="flex items-center gap-1 text-sm text-gray-600 hover:text-blue-600">
                <Edit size={16} />
                编辑
              </button>
              <button
                onClick={() => deleteAddress(address.id)}
                className="flex items-center gap-1 text-sm text-red-500 hover:text-red-600"
              >
                <Trash2 size={16} />
                删除
              </button>
            </div>
          </GlassCard>
        ))}
      </div>
    </TechBackground>
  );
}