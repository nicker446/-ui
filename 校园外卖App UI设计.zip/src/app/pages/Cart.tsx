import { ArrowLeft, MapPin, Plus, Minus, Trash2 } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";
import GlassCard from "../components/GlassCard";
import GlassIconButton from "../components/GlassIconButton";
import GlassButton from "../components/GlassButton";
import TechBackground from "../components/TechBackground";

export default function Cart() {
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState([
    {
      id: "1",
      name: "经典芝士堡",
      price: 28,
      quantity: 2,
      image: "https://images.unsplash.com/photo-1676300187304-7f9b3c97ee8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwY2hlZXNlYnVyZ2VyJTIwY2xvc2UlMjB1cHxlbnwxfHx8fDE3NzIyODY5MTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      restaurant: "精致汉堡工坊",
    },
    {
      id: "2",
      name: "黄金炸鸡翅",
      price: 18,
      quantity: 1,
      image: "https://images.unsplash.com/photo-1766589221324-656419e4c844?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmlzcHklMjBjaGlja2VuJTIwd2luZ3MlMjBmb29kfGVufDF8fHx8MTc3MjI4NjkxNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      restaurant: "精致汉堡工坊",
    },
  ]);

  const [selectedAddress, setSelectedAddress] = useState("校园1号楼 302室");

  const updateQuantity = (id: string, delta: number) => {
    setCartItems((items) =>
      items
        .map((item) =>
          item.id === id ? { ...item, quantity: item.quantity + delta } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeItem = (id: string) => {
    setCartItems((items) => items.filter((item) => item.id !== id));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = 5;
  const total = subtotal + deliveryFee;

  return (
    <TechBackground className="pb-32">
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-4 mb-6">
          <button onClick={() => navigate(-1)} className="w-10 h-10 bg-white/60 backdrop-blur-md rounded-full flex items-center justify-center">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl">购物车</h1>
        </div>

        {/* Delivery Address */}
        <GlassCard
          className="p-4 cursor-pointer hover:scale-[1.01] transition-transform"
          onClick={() => navigate("/address")}
        >
          <div className="flex items-center gap-3">
            <GlassIconButton variant="primary" size="md" className="flex-shrink-0">
              <MapPin size={20} />
            </GlassIconButton>
            <div className="flex-1">
              <div className="text-sm text-gray-500">配送至</div>
              <div className="">{selectedAddress}</div>
            </div>
            <ArrowLeft size={20} className="text-gray-400 rotate-180" />
          </div>
        </GlassCard>
      </div>

      {/* Cart Items */}
      <div className="px-6 mb-6">
        <h2 className="text-xl mb-4">商品清单</h2>
        <div className="space-y-4">
          {cartItems.map((item) => (
            <GlassCard key={item.id} className="p-4">
              <div className="flex gap-4">
                <div className="w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="mb-1">{item.name}</h3>
                  <p className="text-sm text-gray-500 mb-2">{item.restaurant}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-orange-500">¥{item.price}</span>
                    <div className="flex items-center gap-3">
                      <GlassIconButton
                        onClick={() => updateQuantity(item.id, -1)}
                        variant="secondary"
                        size="sm"
                      >
                        <Minus size={14} />
                      </GlassIconButton>
                      <span className="">{item.quantity}</span>
                      <GlassIconButton
                        onClick={() => updateQuantity(item.id, 1)}
                        variant="primary"
                        size="sm"
                      >
                        <Plus size={14} />
                      </GlassIconButton>
                    </div>
                  </div>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>

      {/* Order Summary */}
      <div className="px-6">
        <h2 className="text-xl mb-4">订单摘要</h2>
        <GlassCard className="p-5">
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">商品小计</span>
              <span>¥{subtotal}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">配送费</span>
              <span>¥{deliveryFee}</span>
            </div>
            <div className="border-t border-gray-200/50 pt-3">
              <div className="flex items-center justify-between">
                <span className="">总计</span>
                <span className="text-xl text-orange-500">¥{total}</span>
              </div>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Bottom Action */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-gray-200/50 p-6">
        <div className="max-w-screen-xl mx-auto flex items-center justify-between">
          <div>
            <div className="text-sm text-gray-500">总计</div>
            <div className="text-xl text-orange-500">¥{total}</div>
          </div>
          <GlassButton
            onClick={() => {
              alert("订单已提交！");
              navigate("/orders");
            }}
            variant="primary"
          >
            提交订单
          </GlassButton>
        </div>
      </div>
    </TechBackground>
  );
}