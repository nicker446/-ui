import { ArrowLeft, Search as SearchIcon, Clock, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";
import GlassCard from "../components/GlassCard";
import RestaurantCard from "../components/RestaurantCard";
import FoodCard from "../components/FoodCard";
import GlassButton from "../components/GlassButton";
import TechBackground from "../components/TechBackground";

export default function Search() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [searchHistory, setSearchHistory] = useState([
    "汉堡",
    "寿司",
    "奶茶",
  ]);

  const trendingSearches = [
    "炸鸡",
    "披萨",
    "拉面",
    "沙拉",
    "咖啡",
    "蛋糕",
  ];

  const searchResults = {
    restaurants: [
      {
        name: "精致汉堡工坊",
        image: "https://images.unsplash.com/photo-1558250070-363aa42f9a00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWxpY2lvdXMlMjBidXJnZXIlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXx8fHwxNzcyMjIyNDcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.8,
        deliveryTime: "25-35分钟",
        minOrder: 20,
        category: "西式快餐",
      },
    ],
    foods: [
      {
        name: "经典芝士堡",
        image: "https://images.unsplash.com/photo-1676300187304-7f9b3c97ee8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwY2hlZXNlYnVyZ2VyJTIwY2xvc2UlMjB1cHxlbnwxfHx8fDE3NzIyODY5MTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        price: 28,
        sales: 320,
      },
      {
        name: "黄金炸鸡翅",
        image: "https://images.unsplash.com/photo-1766589221324-656419e4c844?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmlzcHklMjBjaGlja2VuJTIwd2luZ3MlMjBmb29kfGVufDF8fHx8MTc3MjI4NjkxNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        price: 18,
        sales: 456,
      },
    ],
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query && !searchHistory.includes(query)) {
      setSearchHistory([query, ...searchHistory.slice(0, 4)]);
    }
  };

  const clearHistory = () => {
    setSearchHistory([]);
  };

  return (
    <TechBackground>
      {/* Header with Search */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/60 backdrop-blur-md rounded-full flex items-center justify-center flex-shrink-0"
          >
            <ArrowLeft size={20} />
          </button>
          <GlassCard className="flex-1 p-4">
            <div className="flex items-center gap-3">
              <SearchIcon size={20} className="text-gray-400" />
              <input
                type="text"
                placeholder="搜索商家或美食"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch(searchQuery)}
                className="flex-1 bg-transparent outline-none"
                autoFocus
              />
            </div>
          </GlassCard>
        </div>

        {!searchQuery && (
          <>
            {/* Search History */}
            {searchHistory.length > 0 && (
              <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Clock size={18} className="text-gray-500" />
                    <h2 className="text-lg">搜索历史</h2>
                  </div>
                  <button
                    onClick={clearHistory}
                    className="text-sm text-gray-500 hover:text-gray-700"
                  >
                    清空
                  </button>
                </div>
                <div className="flex flex-wrap gap-3">
                  {searchHistory.map((query, index) => (
                    <GlassButton
                      key={index}
                      onClick={() => handleSearch(query)}
                      variant="secondary"
                      size="sm"
                    >
                      {query}
                    </GlassButton>
                  ))}
                </div>
              </div>
            )}

            {/* Trending Searches */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp size={18} className="text-orange-500" />
                <h2 className="text-lg">热门搜索</h2>
              </div>
              <div className="flex flex-wrap gap-3">
                {trendingSearches.map((query, index) => (
                  <button
                    key={index}
                    onClick={() => handleSearch(query)}
                    className="bg-gradient-to-br from-orange-500 to-pink-500 text-white px-4 py-2 rounded-full text-sm hover:shadow-lg transition-shadow"
                  >
                    {query}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      {/* Search Results */}
      {searchQuery && (
        <div className="px-6">
          <div className="mb-8">
            <h2 className="text-xl mb-4">商家</h2>
            <div className="space-y-4">
              {searchResults.restaurants.map((restaurant, index) => (
                <div key={index} onClick={() => navigate(`/restaurant?id=1`)}>
                  <RestaurantCard {...restaurant} />
                </div>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-xl mb-4">美食</h2>
            <div className="grid grid-cols-2 gap-4">
              {searchResults.foods.map((food, index) => (
                <FoodCard key={index} {...food} />
              ))}
            </div>
          </div>
        </div>
      )}
    </TechBackground>
  );
}