import { ArrowLeft, MessageCircle, Phone, Mail, HelpCircle, ChevronRight } from "lucide-react";
import { useNavigate } from "react-router";
import GlassCard from "../components/GlassCard";
import TechBackground from "../components/TechBackground";

export default function Help() {
  const navigate = useNavigate();

  const faqItems = [
    {
      question: "如何下单？",
      answer: "浏览商家，选择商品加入购物车，确认订单后提交即可。",
    },
    {
      question: "配送范围是什么？",
      answer: "目前仅支持校园内配送，覆盖所有宿舍楼、教学楼和图书馆。",
    },
    {
      question: "配送费如何计算？",
      answer: "校园内统一配送费5元，部分商家满额可免配送费。",
    },
    {
      question: "如何使用优惠券？",
      answer: "在结算页面选择可用优惠券，系统会自动抵扣相应金额。",
    },
    {
      question: "订单可以取消吗？",
      answer: "商家接单前可以取消，接单后需要联系客服处理。",
    },
    {
      question: "如何申请退款？",
      answer: "在订单详情页点击申请退款，填写退款原因后提交审核。",
    },
  ];

  const contactMethods = [
    {
      icon: MessageCircle,
      label: "在线客服",
      value: "9:00-22:00",
      color: "bg-blue-500",
    },
    {
      icon: Phone,
      label: "客服电话",
      value: "400-888-8888",
      color: "bg-green-500",
    },
    {
      icon: Mail,
      label: "客服邮箱",
      value: "support@campus.com",
      color: "bg-purple-500",
    },
  ];

  return (
    <TechBackground>
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/60 backdrop-blur-md rounded-full flex items-center justify-center"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl">帮助中心</h1>
        </div>
      </div>

      {/* Contact Methods */}
      <div className="px-6 mb-8">
        <h2 className="text-xl mb-4">联系我们</h2>
        <div className="grid gap-4">
          {contactMethods.map((method) => {
            const Icon = method.icon;
            return (
              <GlassCard
                key={method.label}
                className="p-5 hover:scale-[1.01] transition-transform cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className={`${method.color} w-12 h-12 rounded-2xl flex items-center justify-center`}>
                    <Icon size={24} className="text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="mb-1">{method.label}</h3>
                    <p className="text-sm text-gray-500">{method.value}</p>
                  </div>
                  <ChevronRight size={20} className="text-gray-400" />
                </div>
              </GlassCard>
            );
          })}
        </div>
      </div>

      {/* FAQ */}
      <div className="px-6">
        <h2 className="text-xl mb-4">常见问题</h2>
        <div className="space-y-4">
          {faqItems.map((item, index) => (
            <GlassCard key={index} className="p-5">
              <h3 className="mb-2">{item.question}</h3>
              <p className="text-sm text-gray-600">{item.answer}</p>
            </GlassCard>
          ))}
        </div>
      </div>
    </TechBackground>
  );
}