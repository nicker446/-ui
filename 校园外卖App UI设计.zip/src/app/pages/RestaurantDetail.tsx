import { ArrowLeft, Star, Clock, MapPin, ShoppingCart, Plus, Minus, Heart } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router";
import { useState, useEffect } from "react";
import GlassCard from "../components/GlassCard";
import GlassIconButton from "../components/GlassIconButton";
import GlassButton from "../components/GlassButton";
import TechBackground from "../components/TechBackground";

export default function RestaurantDetail() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const restaurantId = searchParams.get("id") || "1";
  const [cart, setCart] = useState<{ [key: string]: number }>({});
  const [isFavorite, setIsFavorite] = useState(false);

  const restaurants: { [key: string]: any } = {
    "1": {
      name: "精致汉堡工坊",
      image: "https://images.unsplash.com/photo-1558250070-363aa42f9a00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWxpY2lvdXMlMjBidXJnZXIlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXx8fHwxNzcyMjIyNDcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.8,
      deliveryTime: "25-35分钟",
      minOrder: 20,
      category: "西式快餐",
      distance: "1.2km",
      address: "校园东门美食街23号",
    },
    "2": {
      name: "和风寿司料理",
      image: "https://images.unsplash.com/photo-1630748662890-11623a758d6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwc3VzaGklMjBwbGF0dGVyJTIwamFwYW5lc2V8ZW58MXx8fHwxNzcyMTgxMTY1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.9,
      deliveryTime: "30-40分钟",
      minOrder: 35,
      category: "日式料理",
      distance: "0.8km",
      address: "校园西门商业街12号",
    },
    "3": {
      name: "意式披萨屋",
      image: "https://images.unsplash.com/photo-1763478156969-4d7c0ab35590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpc2FuJTIwcGl6emElMjBpdGFsaWFuJTIwY3Vpc2luZXxlbnwxfHx8fDE3NzIyODY4MTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.7,
      deliveryTime: "20-30分钟",
      minOrder: 25,
      category: "西式简餐",
      distance: "1.5km",
      address: "校园南门步行街8号",
    },
  };

  const menuItems = {
    "1": [
      {
        id: "1",
        name: "经典芝士堡",
        price: 28,
        image: "https://images.unsplash.com/photo-1676300187304-7f9b3c97ee8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwY2hlZXNlYnVyZ2VyJTIwY2xvc2UlMjB1cHxlbnwxfHx8fDE3NzIyODY5MTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        sales: 320,
        description: "精选澳洲牛肉，搭配新鲜蔬菜和特制酱料",
      },
      {
        id: "2",
        name: "黄金炸鸡翅",
        price: 18,
        image: "https://images.unsplash.com/photo-1766589221324-656419e4c844?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmlzcHklMjBjaGlja2VuJTIwd2luZ3MlMjBmb29kfGVufDF8fHx8MTc3MjI4NjkxNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        sales: 456,
        description: "外酥里嫩，香气四溢",
      },
      {
        id: "3",
        name: "香脆薯条",
        price: 12,
        image: "https://images.unsplash.com/photo-1707773726979-4b87cd1c838a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb2xkZW4lMjBmcmVuY2glMjBmcmllcyUyMGNyaXNweXxlbnwxfHx8fDE3NzIyNTIyNzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        sales: 567,
        description: "现炸现做，金黄酥脆",
      },
      {
        id: "4",
        name: "草莓奶昔",
        price: 15,
        image: "https://images.unsplash.com/photo-1686638745403-d21193f16b2f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHJhd2JlcnJ5JTIwbWlsa3NoYWtlJTIwcGluayUyMGRyaW5rfGVufDF8fHx8MTc3MjIwNDc3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        sales: 234,
        description: "新鲜草莓现打，香浓顺滑",
      },
    ],
    "2": [
      {
        id: "5",
        name: "三文鱼寿司",
        price: 38,
        image: "https://images.unsplash.com/photo-1763469026756-42f658b969f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYWxtb24lMjBzdXNoaSUyMG5pZ2lyaSUyMGNsb3NlfGVufDF8fHx8MTc3MjI4NjkxNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        sales: 445,
        description: "新鲜三文鱼，当日空运",
      },
      {
        id: "6",
        name: "日式拉面",
        price: 32,
        image: "https://images.unsplash.com/photo-1627900440398-5db32dba8db1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMHJhbWVuJTIwYm93bCUyMGZvb2R8ZW58MXx8fHwxNzcyMjg2OTE2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        sales: 523,
        description: "浓郁汤底，Q弹面条",
      },
    ],
    "3": [
      {
        id: "7",
        name: "玛格丽特披萨",
        price: 42,
        image: "https://images.unsplash.com/photo-1769733338940-c406b721583f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJnaGVyaXRhJTIwcGl6emElMjBpdGFsaWFuJTIwZnJlc2h8ZW58MXx8fHwxNzcyMjg2OTE2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        sales: 389,
        description: "经典意式风味，芝士拉丝",
      },
      {
        id: "8",
        name: "奶油培根意面",
        price: 36,
        image: "https://images.unsplash.com/photo-1764586119076-61711e8ed25a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhbXklMjBjYXJib25hcmElMjBwYXN0YSUyMGRpc2h8ZW58MXx8fHwxNzcyMjg2OTE3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        sales: 267,
        description: "浓郁奶香，培根香脆",
      },
    ],
  };

  const restaurant = restaurants[restaurantId];
  const menu = menuItems[restaurantId as keyof typeof menuItems] || [];

  // 如果餐厅不存在，重定向到首页
  useEffect(() => {
    if (!restaurant) {
      navigate("/");
    }
  }, [restaurant, navigate]);

  // 如果餐厅不存在，显示加载中或空状态
  if (!restaurant) {
    return (
      <TechBackground className="flex items-center justify-center min-h-screen">
        <div className="text-center text-gray-500">加载中...</div>
      </TechBackground>
    );
  }

  const updateCart = (itemId: string, delta: number) => {
    setCart((prev) => {
      const newCount = (prev[itemId] || 0) + delta;
      if (newCount <= 0) {
        const { [itemId]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [itemId]: newCount };
    });
  };

  const totalItems = Object.values(cart).reduce((sum, count) => sum + count, 0);
  const totalPrice = menu.reduce((sum, item) => {
    return sum + item.price * (cart[item.id] || 0);
  }, 0);

  return (
    <TechBackground className="pb-32">
      {/* Header Image */}
      <div className="relative h-64">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="absolute top-8 left-6 w-10 h-10 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center"
        >
          <ArrowLeft size={20} />
        </button>

        {/* Favorite Button */}
        <button
          onClick={() => setIsFavorite(!isFavorite)}
          className="absolute top-8 right-6 w-10 h-10 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center"
        >
          <Heart
            size={20}
            className={isFavorite ? "fill-red-500 text-red-500" : "text-gray-600"}
          />
        </button>

        {/* Restaurant Info */}
        <div className="absolute bottom-6 left-6 right-6">
          <h1 className="text-white text-2xl mb-2">{restaurant.name}</h1>
          <div className="flex items-center gap-4 text-white/90 text-sm">
            <div className="flex items-center gap-1">
              <Star size={16} fill="currentColor" />
              {restaurant.rating}
            </div>
            <div className="flex items-center gap-1">
              <Clock size={16} />
              {restaurant.deliveryTime}
            </div>
            <div className="flex items-center gap-1">
              <MapPin size={16} />
              {restaurant.distance}
            </div>
          </div>
        </div>
      </div>

      {/* Restaurant Details */}
      <div className="px-6 -mt-6">
        <GlassCard className="p-5 mb-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-gray-600">起送金额</span>
            <span className="">¥{restaurant.minOrder}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">商家地址</span>
            <span className="text-sm">{restaurant.address}</span>
          </div>
        </GlassCard>

        {/* Menu Section */}
        <h2 className="text-xl mb-4">菜单</h2>
        <div className="space-y-4">
          {menu.map((item) => (
            <GlassCard key={item.id} className="p-4">
              <div className="flex gap-4">
                <div className="w-24 h-24 rounded-2xl overflow-hidden flex-shrink-0">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="mb-1">{item.name}</h3>
                  <p className="text-sm text-gray-500 mb-2 line-clamp-1">
                    {item.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-orange-500 mr-2">¥{item.price}</span>
                      <span className="text-xs text-gray-400">已售 {item.sales}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      {cart[item.id] > 0 && (
                        <>
                          <GlassIconButton
                            onClick={() => updateCart(item.id, -1)}
                            variant="secondary"
                            size="sm"
                          >
                            <Minus size={14} />
                          </GlassIconButton>
                          <span className="">{cart[item.id]}</span>
                        </>
                      )}
                      <GlassIconButton
                        onClick={() => updateCart(item.id, 1)}
                        variant="primary"
                        size="sm"
                      >
                        <Plus size={14} />
                      </GlassIconButton>
                    </div>
                  </div>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>

      {/* Cart Bottom Bar */}
      {totalItems > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-gray-200/50 p-6">
          <div className="max-w-screen-xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <ShoppingCart size={24} />
                <span className="absolute -top-2 -right-2 w-5 h-5 bg-gradient-to-br from-rose-400 to-pink-400 text-white text-xs rounded-full flex items-center justify-center shadow-lg">
                  {totalItems}
                </span>
              </div>
              <div>
                <div className="text-sm text-gray-500">总计</div>
                <div className="text-xl text-orange-500">¥{totalPrice}</div>
              </div>
            </div>
            <GlassButton onClick={() => navigate("/cart")} variant="primary">
              去结算
            </GlassButton>
          </div>
        </div>
      )}
    </TechBackground>
  );
}