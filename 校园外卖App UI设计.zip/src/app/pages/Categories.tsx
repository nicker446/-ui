import { useNavigate } from "react-router";
import { motion } from "motion/react";
import BottomNav from "../components/BottomNav";
import AnimatedGlassCard from "../components/AnimatedGlassCard";
import PageTransition from "../components/PageTransition";
import { categories } from "../data/categories";
import TechBackground from "../components/TechBackground";

export default function Categories() {
  const navigate = useNavigate();

  // iOS风格的弹簧动画配置
  const springConfig = {
    type: "spring",
    stiffness: 380,
    damping: 28,
    mass: 0.5,
  } as const;

  return (
    <PageTransition>
      <TechBackground>
        {/* Header */}
        <motion.div 
          className="px-6 pt-8 pb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...springConfig, delay: 0.1 }}
        >
          <h1 className="text-2xl mb-2">美食分类</h1>
          <p className="text-gray-500">探索更多美味选择</p>
        </motion.div>

        {/* Categories Grid */}
        <div className="px-6">
          <div className="grid grid-cols-2 gap-4">
            {categories.map((category, index) => {
              const Icon = category.icon;
              return (
                <AnimatedGlassCard
                  key={category.id}
                  className="p-6 cursor-pointer group"
                  onClick={() => navigate(`/category?id=${category.id}&name=${category.name}`)}
                  delay={0.2 + index * 0.06}
                >
                  <motion.div 
                    className={`${category.color} w-16 h-16 rounded-[1.5rem] flex items-center justify-center mb-4 border-2 border-white/40 relative overflow-hidden`}
                    style={{
                      boxShadow: `
                        0 6px 24px rgba(0, 0, 0, 0.15),
                        0 12px 48px rgba(0, 0, 0, 0.1),
                        inset 0 2px 6px rgba(255, 255, 255, 0.5),
                        inset 0 -2px 6px rgba(0, 0, 0, 0.15)
                      `,
                    }}
                    whileHover={{ 
                      scale: 1.15, 
                      rotate: 5,
                      transition: springConfig,
                    }}
                  >
                    {/* 顶部高光 */}
                    <div 
                      className="absolute inset-0 rounded-[1.5rem] pointer-events-none"
                      style={{
                        background: 'radial-gradient(ellipse at top, rgba(255,255,255,0.6) 0%, transparent 60%)',
                      }}
                    />
                    <Icon size={32} className="text-white relative z-10 drop-shadow-md" />
                  </motion.div>
                  <motion.h3 
                    className="mb-1 text-gray-800"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 + index * 0.06 }}
                  >
                    {category.name}
                  </motion.h3>
                  <motion.p 
                    className="text-sm text-gray-500"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.35 + index * 0.06 }}
                  >
                    {category.count} 家商户
                  </motion.p>
                </AnimatedGlassCard>
              );
            })}
          </div>
        </div>

        {/* 添加底部间距，避免被导航栏遮挡 */}
        <div className="h-24" />

        <BottomNav />
      </TechBackground>
    </PageTransition>
  );
}