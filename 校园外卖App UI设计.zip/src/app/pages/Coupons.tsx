import { ArrowLeft, Gift, Clock } from "lucide-react";
import { useNavigate } from "react-router";
import GlassCard from "../components/GlassCard";
import TechBackground from "../components/TechBackground";

export default function Coupons() {
  const navigate = useNavigate();

  const coupons = [
    {
      id: "1",
      type: "满减券",
      amount: 15,
      condition: "满50可用",
      expiry: "2026-03-15",
      status: "available",
    },
    {
      id: "2",
      type: "折扣券",
      discount: "9折",
      condition: "全场通用",
      expiry: "2026-03-20",
      status: "available",
    },
    {
      id: "3",
      type: "满减券",
      amount: 20,
      condition: "满80可用",
      expiry: "2026-03-25",
      status: "available",
    },
    {
      id: "4",
      type: "新人券",
      amount: 10,
      condition: "无门槛",
      expiry: "2026-02-20",
      status: "used",
    },
    {
      id: "5",
      type: "满减券",
      amount: 5,
      condition: "满30可用",
      expiry: "2026-02-15",
      status: "expired",
    },
  ];

  const availableCoupons = coupons.filter((c) => c.status === "available");
  const unavailableCoupons = coupons.filter((c) => c.status !== "available");

  return (
    <TechBackground>
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-4 mb-2">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/60 backdrop-blur-md rounded-full flex items-center justify-center"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl">优惠券</h1>
        </div>
        <p className="text-gray-500 ml-14">{availableCoupons.length} 张可用</p>
      </div>

      {/* Available Coupons */}
      <div className="px-6 mb-8">
        <h2 className="text-xl mb-4">可使用</h2>
        <div className="space-y-4">
          {availableCoupons.map((coupon) => (
            <GlassCard key={coupon.id} className="overflow-hidden">
              <div className="flex">
                <div className="bg-gradient-to-br from-orange-500 to-pink-500 text-white p-6 flex flex-col items-center justify-center min-w-[120px]">
                  <Gift size={24} className="mb-2" />
                  <div className="text-2xl">
                    {coupon.amount ? `¥${coupon.amount}` : coupon.discount}
                  </div>
                </div>
                <div className="flex-1 p-5">
                  <h3 className="mb-1">{coupon.type}</h3>
                  <p className="text-sm text-gray-500 mb-2">{coupon.condition}</p>
                  <div className="flex items-center gap-1 text-xs text-gray-400">
                    <Clock size={12} />
                    有效期至 {coupon.expiry}
                  </div>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>

      {/* Unavailable Coupons */}
      {unavailableCoupons.length > 0 && (
        <div className="px-6">
          <h2 className="text-xl mb-4">不可使用</h2>
          <div className="space-y-4">
            {unavailableCoupons.map((coupon) => (
              <GlassCard key={coupon.id} className="overflow-hidden opacity-50">
                <div className="flex">
                  <div className="bg-gray-400 text-white p-6 flex flex-col items-center justify-center min-w-[120px]">
                    <Gift size={24} className="mb-2" />
                    <div className="text-2xl">
                      {coupon.amount ? `¥${coupon.amount}` : coupon.discount}
                    </div>
                  </div>
                  <div className="flex-1 p-5">
                    <div className="flex items-center gap-2 mb-1">
                      <h3>{coupon.type}</h3>
                      <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded">
                        {coupon.status === "used" ? "已使用" : "已过期"}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500 mb-2">{coupon.condition}</p>
                    <div className="flex items-center gap-1 text-xs text-gray-400">
                      <Clock size={12} />
                      {coupon.expiry}
                    </div>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      )}
    </TechBackground>
  );
}