import { Search, ChevronRight } from "lucide-react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import BottomNav from "../components/BottomNav";
import AnimatedGlassCard from "../components/AnimatedGlassCard";
import PageTransition from "../components/PageTransition";
import RestaurantCard from "../components/RestaurantCard";
import FoodCard from "../components/FoodCard";
import { popularCategories } from "../data/categories";
import { getFeaturedRestaurants } from "../data/restaurants";
import TechBackground from "../components/TechBackground";

export default function Home() {
  const navigate = useNavigate();
  
  const categories = popularCategories.slice(0, 8);
  const restaurants = getFeaturedRestaurants().slice(0, 3);
  
  const popularFoods = [
    {
      name: "招牌拿铁",
      image: "https://images.unsplash.com/photo-1547240089-0b75465f8e80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpc2FuJTIwbGF0dGUlMjBjb2ZmZWUlMjBhcnR8ZW58MXx8fHwxNzcyMjg2ODIwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: 18,
      sales: 1203,
    },
    {
      name: "珍珠奶茶",
      image: "https://images.unsplash.com/photo-1671659420749-d56efede6df4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwYnViYmxlJTIwdGVhJTIwZHJpbmt8ZW58MXx8fHwxNzcyMjg2ODIxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: 15,
      sales: 987,
    },
    {
      name: "轻食沙拉",
      image: "https://images.unsplash.com/photo-1605034298551-baacf17591d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGhlYWx0aHklMjBzYWxhZCUyMGJvd2x8ZW58MXx8fHwxNzcyMjg2ODIzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: 28,
      sales: 756,
    },
    {
      name: "提拉米苏",
      image: "https://images.unsplash.com/photo-1589648219334-23195fe1043d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwdGlyYW1pc3UlMjBkZXNzZXJ0JTIwY2FrZXxlbnwxfHx8fDE3NzIyODY4MjF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: 22,
      sales: 612,
    },
  ];

  // iOS风格的弹簧动画配置
  const springConfig = {
    type: "spring",
    stiffness: 380,
    damping: 28,
    mass: 0.5,
  } as const;

  return (
    <PageTransition>
      <TechBackground>
        {/* Header */}
        <motion.div 
          className="px-6 pt-8 pb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...springConfig, delay: 0.1 }}
        >
          <div className="flex items-center justify-between mb-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ ...springConfig, delay: 0.2 }}
            >
              <h1 className="text-2xl mb-1">你好 👋</h1>
              <p className="text-gray-500">今天想吃什么？</p>
            </motion.div>
          </div>

          {/* Search Bar */}
          <AnimatedGlassCard 
            className="p-4" 
            onClick={() => navigate("/search")}
            delay={0.3}
          >
            <div className="flex items-center gap-3">
              <Search size={20} className="text-gray-400" />
              <input
                type="text"
                placeholder="搜索商家或美食"
                className="flex-1 bg-transparent outline-none pointer-events-none"
              />
            </div>
          </AnimatedGlassCard>
        </motion.div>

        {/* Categories */}
        <div className="px-6 mb-8">
          <div className="grid grid-cols-4 gap-4">
            {categories.map((cat, index) => {
              const Icon = cat.icon;
              return (
                <AnimatedGlassCard 
                  key={cat.id} 
                  className="p-4 text-center cursor-pointer group"
                  onClick={() => navigate(`/category?id=${cat.id}&name=${cat.name}`)}
                  delay={0.4 + index * 0.05}
                >
                  <motion.div 
                    className={`${cat.color} w-12 h-12 rounded-[1.25rem] flex items-center justify-center mx-auto mb-2 border-2 border-white/40 relative overflow-hidden`}
                    style={{
                      boxShadow: `
                        0 4px 16px rgba(0, 0, 0, 0.15),
                        0 8px 32px rgba(0, 0, 0, 0.1),
                        inset 0 2px 4px rgba(255, 255, 255, 0.5),
                        inset 0 -2px 4px rgba(0, 0, 0, 0.15)
                      `,
                    }}
                    whileHover={{ 
                      scale: 1.15, 
                      rotate: 5,
                      transition: springConfig,
                    }}
                  >
                    {/* 顶部高光 */}
                    <div 
                      className="absolute inset-0 rounded-[1.25rem] pointer-events-none"
                      style={{
                        background: 'radial-gradient(ellipse at top, rgba(255,255,255,0.6) 0%, transparent 60%)',
                      }}
                    />
                    <Icon size={24} className="text-white relative z-10 drop-shadow-sm" />
                  </motion.div>
                  <span className="text-sm text-gray-700">{cat.name}</span>
                </AnimatedGlassCard>
              );
            })}
          </div>
        </div>

        {/* Popular Foods */}
        <div className="px-6 mb-8">
          <motion.div 
            className="flex items-center justify-between mb-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ ...springConfig, delay: 0.8 }}
          >
            <h2 className="text-xl">热门美食</h2>
            <motion.button 
              onClick={() => navigate("/categories")}
              className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700"
              whileHover={{ x: 4 }}
              whileTap={{ scale: 0.95 }}
            >
              更多 <ChevronRight size={16} />
            </motion.button>
          </motion.div>
          <div className="grid grid-cols-2 gap-4">
            {popularFoods.map((food, index) => (
              <motion.div 
                key={food.name} 
                onClick={() => navigate(`/restaurant?id=${index + 1}`)}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ ...springConfig, delay: 0.9 + index * 0.1 }}
                whileHover={{ 
                  scale: 1.05, 
                  y: -8,
                  transition: springConfig,
                }}
                whileTap={{ scale: 0.98 }}
              >
                <FoodCard {...food} />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Recommended Restaurants */}
        <div className="px-6">
          <motion.div 
            className="flex items-center justify-between mb-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ ...springConfig, delay: 1.3 }}
          >
            <h2 className="text-xl">推荐商家</h2>
            <motion.button 
              onClick={() => navigate("/all-restaurants")}
              className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700"
              whileHover={{ x: 4 }}
              whileTap={{ scale: 0.95 }}
            >
              更多 <ChevronRight size={16} />
            </motion.button>
          </motion.div>
          <div className="space-y-4">
            {restaurants.map((restaurant, index) => (
              <motion.div 
                key={restaurant.name} 
                onClick={() => navigate(`/restaurant?id=${index + 1}`)}
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ ...springConfig, delay: 1.4 + index * 0.1 }}
                whileHover={{ 
                  scale: 1.02, 
                  x: 8,
                  transition: springConfig,
                }}
                whileTap={{ scale: 0.98 }}
              >
                <RestaurantCard {...restaurant} />
              </motion.div>
            ))}
          </div>
        </div>

        {/* 添加底部间距，避免被导航栏遮挡 */}
        <div className="h-24" />

        <BottomNav />
      </TechBackground>
    </PageTransition>
  );
}