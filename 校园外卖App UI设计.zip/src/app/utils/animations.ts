// iOS风格的动画配置集合

// 标准弹簧动画配置
export const springConfig = {
  type: "spring",
  stiffness: 380,
  damping: 28,
  mass: 0.5,
} as const;

// 轻盈弹簧配置（用于快速交互）
export const lightSpringConfig = {
  type: "spring",
  stiffness: 500,
  damping: 25,
  mass: 0.3,
} as const;

// 柔和弹簧配置（用于大元素）
export const softSpringConfig = {
  type: "spring",
  stiffness: 300,
  damping: 30,
  mass: 0.8,
} as const;

// 页面转场动画变体
export const pageVariants = {
  initial: {
    opacity: 0,
    x: 20,
    scale: 0.98,
  },
  animate: {
    opacity: 1,
    x: 0,
    scale: 1,
  },
  exit: {
    opacity: 0,
    x: -20,
    scale: 0.98,
  },
};

// 淡入动画
export const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
};

// 淡入从左侧
export const fadeInLeft = {
  initial: { opacity: 0, x: -30 },
  animate: { opacity: 1, x: 0 },
};

// 淡入从右侧
export const fadeInRight = {
  initial: { opacity: 0, x: 30 },
  animate: { opacity: 1, x: 0 },
};

// 缩放进入
export const scaleIn = {
  initial: { opacity: 0, scale: 0.9 },
  animate: { opacity: 1, scale: 1 },
};

// 旋转进入
export const rotateIn = {
  initial: { opacity: 0, scale: 0, rotate: -180 },
  animate: { opacity: 1, scale: 1, rotate: 0 },
};

// 交错动画容器
export const staggerContainerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.1,
    },
  },
};

// 交错动画子项
export const staggerItemVariants = {
  hidden: { 
    opacity: 0, 
    y: 20,
    scale: 0.95,
  },
  show: { 
    opacity: 1, 
    y: 0,
    scale: 1,
    transition: springConfig,
  },
};

// Hover动画
export const hoverScale = {
  scale: 1.05,
  y: -4,
  transition: springConfig,
};

// Tap动画
export const tapScale = {
  scale: 0.98,
  transition: lightSpringConfig,
};

// 悬浮卡片动画
export const cardHover = {
  scale: 1.02,
  y: -8,
  transition: springConfig,
};

// 按钮悬浮动画
export const buttonHover = {
  scale: 1.05,
  y: -2,
  transition: lightSpringConfig,
};

// 图标旋转动画
export const iconRotate = {
  rotate: 360,
  scale: 1.2,
  transition: { duration: 0.5, ease: "easeInOut" },
};

// 图标摇摆动画
export const iconWiggle = {
  rotate: [0, -10, 10, -10, 0],
  transition: { duration: 0.6, ease: "easeInOut" },
};
