export interface Restaurant {
  id: string;
  name: string;
  image: string;
  rating: number;
  deliveryTime: string;
  minOrder: number;
  category: string;
  categoryId: string;
}

export const restaurants: Restaurant[] = [
  // 中式快餐
  {
    id: "1",
    name: "老友记盖浇饭",
    image: "https://images.unsplash.com/photo-1664717698774-84f62382613b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwY2hpbmVzZSUyMHJpY2UlMjBib3dsJTIwZm9vZHxlbnwxfHx8fDE3NzIyODY4MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.7,
    deliveryTime: "20-30分钟",
    minOrder: 15,
    category: "中式快餐",
    categoryId: "chinese-fast-food"
  },
  {
    id: "2",
    name: "黄焖鸡米饭",
    image: "https://images.unsplash.com/photo-1757715377671-01c20cfa1880?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwY2hpY2tlbiUyMHJpY2UlMjBhc2lhbiUyMGN1aXNpbmV8ZW58MXx8fHwxNzcyMjg2ODE3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.6,
    deliveryTime: "25-35分钟",
    minOrder: 18,
    category: "中式快餐",
    categoryId: "chinese-fast-food"
  },
  
  // 西式快餐
  {
    id: "3",
    name: "精致汉堡工坊",
    image: "https://images.unsplash.com/photo-1558250070-363aa42f9a00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWxpY2lvdXMlMjBidXJnZXIlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXx8fHwxNzcyMjIyNDcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.8,
    deliveryTime: "25-35分钟",
    minOrder: 20,
    category: "西式快餐",
    categoryId: "western-fast-food"
  },
  {
    id: "4",
    name: "意式披萨屋",
    image: "https://images.unsplash.com/photo-1763478156969-4d7c0ab35590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpc2FuJTIwcGl6emElMjBpdGFsaWFuJTIwY3Vpc2luZXxlbnwxfHx8fDE3NzIyODY4MTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.7,
    deliveryTime: "20-30分钟",
    minOrder: 25,
    category: "西式快餐",
    categoryId: "western-fast-food"
  },
  
  // 面食小吃
  {
    id: "5",
    name: "兰州拉面馆",
    image: "https://images.unsplash.com/photo-1762674462382-6ea7fb670032?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRoZW50aWMlMjByYW1lbiUyMG5vb2RsZXMlMjBqYXBhbmVzZXxlbnwxfHx8fDE3NzIyODY4MTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.8,
    deliveryTime: "15-25分钟",
    minOrder: 12,
    category: "面食小吃",
    categoryId: "noodles-snacks"
  },
  {
    id: "6",
    name: "云南过桥米线",
    image: "https://images.unsplash.com/photo-1701480253822-1842236c9a97?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxWaWV0bmFtZXNlJTIwcGhvJTIwbm9vZGxlJTIwc291cHxlbnwxfHx8fDE3NzIyODY4MTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.7,
    deliveryTime: "20-30分钟",
    minOrder: 16,
    category: "面食小吃",
    categoryId: "noodles-snacks"
  },
  
  // 日韩料理
  {
    id: "7",
    name: "和风寿司料理",
    image: "https://images.unsplash.com/photo-1630748662890-11623a758d6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwc3VzaGklMjBwbGF0dGVyJTIwamFwYW5lc2V8ZW58MXx8fHwxNzcyMTgxMTY1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.9,
    deliveryTime: "30-40分钟",
    minOrder: 35,
    category: "日韩料理",
    categoryId: "japanese-korean"
  },
  {
    id: "8",
    name: "韩式石锅拌饭",
    image: "https://images.unsplash.com/photo-1741295017668-c8132acd6fc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBiaWJpbWJhcCUyMGJvd2wlMjBmb29kfGVufDF8fHx8MTc3MjI4NjgyMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.6,
    deliveryTime: "25-35分钟",
    minOrder: 28,
    category: "日韩料理",
    categoryId: "japanese-korean"
  },
  
  // 咖啡饮品
  {
    id: "9",
    name: "星空咖啡馆",
    image: "https://images.unsplash.com/photo-1547240089-0b75465f8e80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpc2FuJTIwbGF0dGUlMjBjb2ZmZWUlMjBhcnR8ZW58MXx8fHwxNzcyMjg2ODIwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.9,
    deliveryTime: "10-20分钟",
    minOrder: 15,
    category: "咖啡饮品",
    categoryId: "coffee-drinks"
  },
  {
    id: "10",
    name: "茶颜悦色奶茶",
    image: "https://images.unsplash.com/photo-1671659420749-d56efede6df4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwYnViYmxlJTIwdGVhJTIwZHJpbmt8ZW58MXx8fHwxNzcyMjg2ODIxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.8,
    deliveryTime: "15-25分钟",
    minOrder: 12,
    category: "咖啡饮品",
    categoryId: "coffee-drinks"
  },
  
  // 甜品烘焙
  {
    id: "11",
    name: "甜蜜烘焙坊",
    image: "https://images.unsplash.com/photo-1589648219334-23195fe1043d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwdGlyYW1pc3UlMjBkZXNzZXJ0JTIwY2FrZXxlbnwxfHx8fDE3NzIyODY4MjF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.9,
    deliveryTime: "25-35分钟",
    minOrder: 28,
    category: "甜品烘焙",
    categoryId: "dessert-bakery"
  },
  {
    id: "12",
    name: "冰雪皇后",
    image: "https://images.unsplash.com/photo-1757856632627-0c2b8453348f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaWNlJTIwY3JlYW0lMjBkZXNzZXJ0fGVufDF8fHx8MTc3MjI4NjgyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.7,
    deliveryTime: "20-30分钟",
    minOrder: 18,
    category: "甜品烘焙",
    categoryId: "dessert-bakery"
  },
  
  // 烧烤火锅
  {
    id: "13",
    name: "麻辣香锅",
    image: "https://images.unsplash.com/photo-1666278172017-ad93e14c329d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGljeSUyMGNoaW5lc2UlMjBob3Rwb3QlMjBmb29kfGVufDF8fHx8MTc3MjI4NjgyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.6,
    deliveryTime: "20-30分钟",
    minOrder: 18,
    category: "烧烤火锅",
    categoryId: "bbq-hotpot"
  },
  {
    id: "14",
    name: "烧烤大排档",
    image: "https://images.unsplash.com/photo-1763480005787-67c0fe4ee8f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmlsbGVkJTIwc2tld2VycyUyMGJhcmJlY3VlJTIwZm9vZHxlbnwxfHx8fDE3NzIyODY4MjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.5,
    deliveryTime: "30-40分钟",
    minOrder: 25,
    category: "烧烤火锅",
    categoryId: "bbq-hotpot"
  },
  
  // 健康轻食
  {
    id: "15",
    name: "轻食沙拉吧",
    image: "https://images.unsplash.com/photo-1605034298551-baacf17591d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGhlYWx0aHklMjBzYWxhZCUyMGJvd2x8ZW58MXx8fHwxNzcyMjg2ODIzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.8,
    deliveryTime: "15-25分钟",
    minOrder: 22,
    category: "健康轻食",
    categoryId: "light-meals"
  },
  {
    id: "16",
    name: "健身餐轻食",
    image: "https://images.unsplash.com/photo-1667499745120-f9bcef8f584e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwbWVhbCUyMHByZXAlMjBib3dsfGVufDF8fHx8MTc3MjE5MDM1M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.7,
    deliveryTime: "20-30分钟",
    minOrder: 26,
    category: "健康轻食",
    categoryId: "light-meals"
  },
];

// 根据分类ID获取餐厅
export function getRestaurantsByCategory(categoryId: string): Restaurant[] {
  return restaurants.filter(r => r.categoryId === categoryId);
}

// 获取推荐餐厅
export function getFeaturedRestaurants(): Restaurant[] {
  return restaurants.slice(0, 6);
}