import { 
  Utensils, 
  Coffee, 
  Pizza, 
  IceCream, 
  Soup,
  Beef,
  Fish,
  Cake,
  Apple,
  Flame,
  UtensilsCrossed,
  Cookie
} from "lucide-react";

export interface Category {
  id: string;
  icon: any;
  name: string;
  count: number;
  color: string;
  description?: string;
}

export const categories: Category[] = [
  {
    id: "chinese-fast-food",
    icon: Utensils,
    name: "中式快餐",
    count: 256,
    color: "bg-gradient-to-br from-rose-400/80 to-red-400/70",
    description: "米饭套餐、盖浇饭、炒菜"
  },
  {
    id: "western-fast-food",
    icon: Pizza,
    name: "西式快餐",
    count: 189,
    color: "bg-gradient-to-br from-orange-400/80 to-amber-400/70",
    description: "汉堡、炸鸡、披萨"
  },
  {
    id: "noodles-snacks",
    icon: Soup,
    name: "面食小吃",
    count: 312,
    color: "bg-gradient-to-br from-amber-400/80 to-yellow-400/70",
    description: "面条、米线、馄饨、粉丝"
  },
  {
    id: "japanese-korean",
    icon: Fish,
    name: "日韩料理",
    count: 98,
    color: "bg-gradient-to-br from-sky-400/80 to-blue-400/70",
    description: "寿司、拉面、石锅拌饭"
  },
  {
    id: "coffee-drinks",
    icon: Coffee,
    name: "咖啡饮品",
    count: 167,
    color: "bg-gradient-to-br from-amber-500/80 to-orange-500/70",
    description: "咖啡、奶茶、果汁"
  },
  {
    id: "dessert-bakery",
    icon: IceCream,
    name: "甜品烘焙",
    count: 145,
    color: "bg-gradient-to-br from-pink-400/80 to-rose-400/70",
    description: "蛋糕、面包、冰淇淋"
  },
  {
    id: "bbq-hotpot",
    icon: Flame,
    name: "烧烤火锅",
    count: 134,
    color: "bg-gradient-to-br from-red-400/80 to-rose-500/70",
    description: "烧烤、麻辣烫、火锅"
  },
  {
    id: "light-meals",
    icon: UtensilsCrossed,
    name: "健康轻食",
    count: 89,
    color: "bg-gradient-to-br from-emerald-400/80 to-green-400/70",
    description: "沙拉、健身餐、低卡餐"
  },
  {
    id: "steak-western",
    icon: Beef,
    name: "牛排西餐",
    count: 67,
    color: "bg-gradient-to-br from-purple-400/80 to-violet-400/70",
    description: "牛排、意面、西餐简餐"
  },
  {
    id: "snacks-fried",
    icon: Cookie,
    name: "小吃炸串",
    count: 203,
    color: "bg-gradient-to-br from-yellow-400/80 to-amber-400/70",
    description: "炸串、关东煮、小吃"
  },
  {
    id: "fruits-fresh",
    icon: Apple,
    name: "水果生鲜",
    count: 234,
    color: "bg-gradient-to-br from-teal-400/80 to-emerald-400/70",
    description: "新鲜水果、果切、沙拉"
  },
  {
    id: "cakes-pastries",
    icon: Cake,
    name: "蛋糕甜点",
    count: 156,
    color: "bg-gradient-to-br from-rose-400/80 to-pink-400/70",
    description: "生日蛋糕、甜点、下午茶"
  },
];

// 热门分类（首页显示）
export const popularCategories = [
  categories.find(c => c.id === "chinese-fast-food")!,
  categories.find(c => c.id === "western-fast-food")!,
  categories.find(c => c.id === "coffee-drinks")!,
  categories.find(c => c.id === "dessert-bakery")!,
  categories.find(c => c.id === "noodles-snacks")!,
  categories.find(c => c.id === "japanese-korean")!,
  categories.find(c => c.id === "bbq-hotpot")!,
  categories.find(c => c.id === "light-meals")!,
];